#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Notepad + Paint (Python / Tkinter + Pillow port)
=================================================

원본은 브라우저에서 돌아가는 단일 HTML 파일(Windows98/XP 스타일 메모장 + 그림판)
이었습니다. 이 파일은 그 앱의 기능을 최대한 비슷하게 데스크탑 파이썬 앱으로
옮긴 것입니다.

필요한 패키지:
    pip install Pillow

실행:
    python notepad_paint.py

참고: 기본 폰트는 'Noto Serif KR'로 설정되어 있습니다. 원본은 이 폰트를 구글 폰트
웹폰트로 자동 불러왔지만, 데스크탑 tkinter는 OS에 실제로 설치된 폰트만 쓸 수 있습니다.
'Noto Serif KR'이 시스템에 설치되어 있지 않으면 tkinter가 조용히 기본 폰트로 대체해서
보여줍니다 (에러는 안 남). 정확히 똑같이 보이게 하려면 Noto Serif KR 폰트를 OS에 설치해
주세요.

원본과 다른 점 (브라우저 전용 기능이라 데스크탑에는 그대로 옮길 수 없는 부분):
  - localStorage 자동저장  -> 스크립트와 같은 폴더의 .notepad_autosave.json 파일로 대체
  - <input type=file> / Blob 다운로드 -> 표준 파일 열기/저장 대화상자로 대체
  - 이미지 드래그(고스트 이미지 따라다니는 것) -> 클릭으로 선택 후 위/아래/좌우
    화살표 또는 드래그로 이동하는 방식으로 단순화
  - CSS 그라데이션 타이틀바 등 일부 장식은 tkinter 한계로 단색으로 근사
"""

import base64
import copy
import io
import json
import os
import re
from html.parser import HTMLParser

import tkinter as tk
from tkinter import ttk, filedialog, messagebox, simpledialog

import webbrowser

try:
    from PIL import Image, ImageDraw, ImageTk, ImageChops
except ImportError:  # pragma: no cover
    raise SystemExit(
        "Pillow가 필요합니다. 먼저 'pip install Pillow' 를 실행한 뒤 다시 실행해주세요."
    )

# ----------------------------------------------------------------------------
# 공통 색상 / 상수 (원본 CSS 변수와 최대한 맞춤)
# ----------------------------------------------------------------------------
GRAY = "#C0C0C0"
DARK_GRAY = "#808080"
BORDER_NAVY = "#000080"
TITLEBAR_BLUE = "#000080"

AVAILABLE_FONTS = [
    "Noto Serif KR", "Nanum Myeongjo", "Malgun Gothic", "Times New Roman",
    "Georgia", "Cambria", "Arial", "Courier New", "Comic Sans MS",
    "Verdana", "Tahoma", "Impact",
]
DEFAULT_FONT_FAMILY = "Noto Serif KR"

AUTOSAVE_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), ".notepad_autosave.json")

# 타이핑 중 URL처럼 생긴 단어를 자동으로 링크로 바꿔주는 정규식 (원본과 동일한 로직)
URL_REGEX = re.compile(
    r"(?:https?://)?(?:www\.)?[a-zA-Z0-9][a-zA-Z0-9-]*(?:\.[a-zA-Z0-9-]+)*\."
    r"(?:com|net|org|io|co|kr|dev|app|edu|gov|info|xyz|me|us|uk|jp|cn)(?:/\S*)?",
    re.IGNORECASE,
)


def clamp(v, lo, hi):
    return max(lo, min(hi, v))


# ----------------------------------------------------------------------------
# 아주 작은 HTML 파서 (원본이 innerHTML 을 그대로 저장/복원하던 방식을 최대한 흉내)
# b/strong, i/em, u, s/strike, font(size/color), img(src=data uri) 정도만 지원
# ----------------------------------------------------------------------------
class _SimpleHTMLImporter(HTMLParser):
    def __init__(self, editor):
        super().__init__(convert_charrefs=True)
        self.editor = editor
        self.stack = []  # list of dict: {'bold':..,'italic':..,'underline':..,'strike':..,'color':..,'size':..}
        self.cur = {"bold": False, "italic": False, "underline": False, "strike": False, "color": None, "size": None}

    def _push(self, **kw):
        self.stack.append(dict(self.cur))
        self.cur.update(kw)

    def _pop(self):
        if self.stack:
            self.cur = self.stack.pop()

    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        tag = tag.lower()
        if tag in ("b", "strong"):
            self._push(bold=True)
        elif tag in ("i", "em"):
            self._push(italic=True)
        elif tag == "u":
            self._push(underline=True)
        elif tag in ("s", "strike", "del"):
            self._push(strike=True)
        elif tag == "font":
            kw = {}
            if attrs.get("color"):
                kw["color"] = attrs["color"]
            self._push(**kw)
        elif tag == "span":
            style = attrs.get("style", "")
            kw = {}
            m = re.search(r"font-size\s*:\s*(\d+)px", style)
            if m:
                kw["size"] = int(m.group(1))
            m = re.search(r"color\s*:\s*(#[0-9a-fA-F]{3,6})", style)
            if m:
                kw["color"] = m.group(1)
            self._push(**kw)
        elif tag == "br":
            self.editor.insert_plain_text("\n", dict(self.cur))
        elif tag == "img":
            src = attrs.get("src", "")
            self.editor.insert_image_from_src(src)

    def handle_endtag(self, tag):
        tag = tag.lower()
        if tag in ("b", "strong", "i", "em", "u", "s", "strike", "del", "font", "span"):
            self._pop()
        if tag == "p" or tag == "div":
            self.editor.insert_plain_text("\n", dict(self.cur))

    def handle_data(self, data):
        if data:
            self.editor.insert_plain_text(data, dict(self.cur))


# ----------------------------------------------------------------------------
# 메모장 (Notepad)
# ----------------------------------------------------------------------------
class NotepadApp:
    def __init__(self, root):
        self.root = root
        self.current_file_name = None
        self.current_file_path = None
        self.unsaved = False
        self.font_family = DEFAULT_FONT_FAMILY
        self.font_size_px = 16
        self.border_color = BORDER_NAVY
        self.dark_mode = False
        self.images = {}          # image_id -> {'pil': Image, 'photo': ImageTk.PhotoImage, 'tag': str}
        self.selected_image_id = None
        self.paint_window = None
        self._img_counter = 0
        self._link_counter = 0
        self._autosave_job = None
        self._is_fullscreen = False

        self._build_ui()
        self._bind_shortcuts()
        self.title_update()
        self.update_status()
        self.root.after(300, self._try_restore_autosave)

    # ---------------- UI 구성 ----------------
    def _build_ui(self):
        self.root.configure(bg=GRAY)
        self.root.geometry("1000x700")
        # 창 제목은 OS 타이틀바(윗쪽 파란 커스텀 바 없이)로만 표시
        self.title_label = None

        # ---- 메뉴바 ----
        menubar = tk.Menu(self.root)
        self.root.config(menu=menubar)

        file_menu = tk.Menu(menubar, tearoff=0)
        file_menu.add_command(label="New file      Ctrl+N", command=self.do_new)
        file_menu.add_command(label="Open          Ctrl+O", command=self.do_open)
        file_menu.add_command(label="Save          Ctrl+S", command=self.do_save)
        file_menu.add_command(label="Save as...    Ctrl+Shift+S", command=self.do_save_as)
        menubar.add_cascade(label="File(F)", menu=file_menu)

        edit_menu = tk.Menu(menubar, tearoff=0)
        edit_menu.add_command(label="Undo          Ctrl+Z", command=self.do_undo)
        edit_menu.add_command(label="Redo          Ctrl+Y", command=self.do_redo)
        edit_menu.add_separator()
        edit_menu.add_command(label="Select all    Ctrl+A", command=self.select_all_text)
        menubar.add_cascade(label="Edit(E)", menu=edit_menu)

        insert_menu = tk.Menu(menubar, tearoff=0)
        insert_menu.add_command(label="Insert image", command=self.insert_image_dialog)
        insert_menu.add_command(label="Resize image", command=self.open_image_resize)
        insert_menu.add_separator()
        insert_menu.add_command(label="Open Paint...", command=self.open_paint)
        menubar.add_cascade(label="Insert(I)", menu=insert_menu)

        format_menu = tk.Menu(menubar, tearoff=0)
        format_menu.add_command(label="Change font", command=self.open_font_list)
        format_menu.add_command(label="Change font size", command=self.open_font_size)
        format_menu.add_separator()
        format_menu.add_command(label="Bold          Ctrl+B", command=lambda: self.toggle_inline("bold"))
        format_menu.add_command(label="Italic        Ctrl+Shift+I", command=lambda: self.toggle_inline("italic"))
        format_menu.add_command(label="Underline     Ctrl+U", command=lambda: self.toggle_inline("underline"))
        format_menu.add_command(label="Strike        Ctrl+Shift+X", command=lambda: self.toggle_inline("overstrike"))
        format_menu.add_separator()
        format_menu.add_command(label="Change bg color", command=self.change_bg_color)
        format_menu.add_command(label="Change text color", command=self.change_text_color)
        format_menu.add_separator()
        format_menu.add_command(label="Change border color", command=self.change_border_color)
        format_menu.add_separator()
        format_menu.add_command(label="Turn on / off dark mode", command=self.toggle_dark_mode)
        menubar.add_cascade(label="Format(O)", menu=format_menu)

        # ---- 툴바 ----
        toolbar = tk.Frame(self.root, bg=GRAY)
        toolbar.pack(fill="x", side="top")

        def tbtn(parent, text, cmd, **kw):
            b = tk.Button(parent, text=text, command=cmd, relief="raised", bg=GRAY, padx=6, **kw)
            b.pack(side="left", padx=2, pady=3)
            return b

        tbtn(toolbar, "New file", self.do_new)
        tbtn(toolbar, "Open", self.do_open)
        tbtn(toolbar, "Save", self.do_save)
        tbtn(toolbar, "\u21b6", self.do_undo)
        tbtn(toolbar, "\u21b7", self.do_redo)
        self.bold_btn = tbtn(toolbar, "B", lambda: self.toggle_inline("bold"), font=("Malgun Gothic", 10, "bold"))
        self.italic_btn = tbtn(toolbar, "I", lambda: self.toggle_inline("italic"), font=("Malgun Gothic", 10, "italic"))
        self.underline_btn = tbtn(toolbar, "U", lambda: self.toggle_inline("underline"), font=("Malgun Gothic", 10, "underline"))
        self.strike_btn = tbtn(toolbar, "S", lambda: self.toggle_inline("overstrike"), font=("Malgun Gothic", 10, "overstrike"))
        tbtn(toolbar, "Insert image", self.insert_image_dialog)
        tbtn(toolbar, "Paint", self.open_paint)
        tbtn(toolbar, "Dark mode", self.toggle_dark_mode)
        self.fullscreen_btn = tbtn(toolbar, "Fullscreen", self.toggle_fullscreen)
        tk.Label(toolbar, text="Made by F3L1X_", bg=GRAY, fg=DARK_GRAY,
                 font=("Malgun Gothic", 8, "italic")).pack(side="right", padx=6)

        # ---- 상태바 ----
        # tkinter pack()은 순서대로 공간을 배분하기 때문에, expand=True로 늘어나는
        # 에디터 영역보다 상태바를 먼저 배치해둬야 밑에 자리가 남아 보임
        # (반대로 하면 에디터가 남은 공간을 다 먹어버려서 상태바가 안 보이게 됨)
        self.statusbar = tk.Label(self.root, text="Chars: 0 | Words: 0 | Ln 1, Col 1", bg=GRAY,
                                   anchor="e", font=("Malgun Gothic", 9), bd=1, relief="groove")
        self.statusbar.pack(fill="x", side="bottom")

        # ---- 에디터 ----
        editor_wrap = tk.Frame(self.root, bg=GRAY, padx=6, pady=6)
        editor_wrap.pack(fill="both", expand=True)
        self.editor_border = tk.Frame(editor_wrap, bg=self.border_color, bd=3)
        self.editor_border.pack(fill="both", expand=True)

        text_frame = tk.Frame(self.editor_border, bg=GRAY, padx=2, pady=2)
        text_frame.pack(fill="both", expand=True)

        yscroll = tk.Scrollbar(text_frame)
        yscroll.pack(side="right", fill="y")
        self.editor = tk.Text(text_frame, wrap="word", undo=True, autoseparators=True,
                               font=(self.font_family, self.font_size_px), yscrollcommand=yscroll.set,
                               bg="white", fg="black", relief="flat", padx=10, pady=10)
        self.editor.pack(side="left", fill="both", expand=True)
        yscroll.config(command=self.editor.yview)

        # 서식 태그
        self.editor.tag_configure("bold", font=self._font_variant(bold=True))
        self.editor.tag_configure("italic", font=self._font_variant(italic=True))
        self.editor.tag_configure("underline", underline=True)
        self.editor.tag_configure("overstrike", overstrike=True)

        # 이벤트
        self.editor.bind("<<Modified>>", self._on_modified)
        self.editor.bind("<KeyRelease>", self._on_editor_key_release)
        self.editor.bind("<ButtonRelease-1>", self._on_editor_click_release)

    def _font_variant(self, bold=False, italic=False):
        style = []
        if bold:
            style.append("bold")
        if italic:
            style.append("italic")
        return (self.font_family, self.font_size_px, " ".join(style)) if style else (self.font_family, self.font_size_px)

    def _bind_shortcuts(self):
        r = self.root

        def guarded(fn):
            # Paint 창이 열려있는 동안엔 메모장 전역 단축키(Ctrl+Z/S/N 등)가
            # 같이 발동하면 안 됨 (원본 JS도 Paint 열려있을 때는 이 단축키들을 무시함)
            def handler(event=None):
                if self.paint_window is not None and self.paint_window.winfo_exists():
                    return
                fn()
            return handler

        r.bind_all("<Control-n>", guarded(self.do_new))
        r.bind_all("<Control-o>", guarded(self.do_open))
        r.bind_all("<Control-s>", guarded(self.do_save))
        r.bind_all("<Control-Shift-S>", guarded(self.do_save_as))
        r.bind_all("<Control-z>", guarded(self.do_undo))
        r.bind_all("<Control-y>", guarded(self.do_redo))
        r.bind_all("<Control-a>", guarded(self.select_all_text))
        r.bind_all("<Control-b>", guarded(lambda: self.toggle_inline("bold")))
        r.bind_all("<Control-u>", guarded(lambda: self.toggle_inline("underline")))
        r.bind_all("<Control-Shift-X>", guarded(lambda: self.toggle_inline("overstrike")))

        # Ctrl+I는 뺐음: X11/리눅스 계열에서는 물리적으로 Ctrl+I를 누르면 Tk에
        # "i" 키가 아니라 "Tab" 키(둘 다 아스키 0x09라서 키보드 레벨에서 같은 걸로
        # 취급됨)로 전달돼서 안정적으로 동작하지 않음. 그래서 Italic은
        # Ctrl+Shift+I로 바꿈 (이건 Tab이랑 안 겹침).
        r.bind_all("<Control-Shift-I>", guarded(lambda: self.toggle_inline("italic")))

        r.protocol("WM_DELETE_WINDOW", self._on_close)

    # ---------------- 상태 관리 ----------------
    def _on_modified(self, event=None):
        if self.editor.edit_modified():
            self.mark_unsaved()
            self.editor.edit_modified(False)

    def mark_unsaved(self):
        self.unsaved = True
        self._schedule_autosave()

    def title_update(self):
        t = (self.current_file_name or "Untitled") + " - Notepad"
        self.root.title(t)

    def update_status(self):
        content = self.editor.get("1.0", "end-1c")
        chars = len(content)
        words = len([w for w in re.split(r"\s+", content) if w])
        idx = self.editor.index("insert")
        line, col = idx.split(".")
        if self.selected_image_id and self.selected_image_id in self.images:
            info = self.images[self.selected_image_id]["pil"]
            self.statusbar.config(text=f"Image selected (Size: {info.width}x{info.height}px)")
        else:
            self.statusbar.config(text=f"Chars: {chars} | Words: {words} | Ln {line}, Col {col}")

    def toggle_fullscreen(self):
        self._is_fullscreen = not self._is_fullscreen
        self.root.attributes("-fullscreen", self._is_fullscreen)
        self.fullscreen_btn.config(text="Exit fullscreen" if self._is_fullscreen else "Fullscreen")

    # ---------------- 자동 링크 ----------------
    def _on_editor_key_release(self, event):
        self.update_status()
        self._try_autolink(event)

    def _try_autolink(self, event):
        # 원본처럼: 단어를 다 타이핑하고 스페이스/엔터를 눌러야(=단어를 "지나가야") 링크로 바뀜
        if event.keysym not in ("space", "Return"):
            return
        end_index = self.editor.index("insert -1c")  # 방금 친 공백/엔터 앞, 즉 단어 끝
        line_no = end_index.split(".")[0]
        line_start = f"{line_no}.0"
        text_before = self.editor.get(line_start, end_index)
        m = re.search(r"(\S+)$", text_before)
        if not m:
            return
        word = m.group(1)
        if not URL_REGEX.fullmatch(word):
            return
        if "link" in self.editor.tag_names(f"{end_index} -1c"):
            return  # 이미 링크로 처리된 상태
        start_col = int(end_index.split(".")[1]) - len(word)
        start_index = f"{line_no}.{start_col}"
        href = word if re.match(r"^https?://", word, re.IGNORECASE) else "https://" + word
        self._make_link(start_index, end_index, href)

    def _make_link(self, start, end, href):
        self._link_counter += 1
        tagname = f"link_{self._link_counter}"
        self.editor.tag_add(tagname, start, end)
        self.editor.tag_add("link", start, end)
        self.editor.tag_configure(tagname, foreground="#0000EE", underline=True)
        self.editor.tag_bind(tagname, "<Button-1>", lambda e, h=href: webbrowser.open(h))
        self.editor.tag_bind(tagname, "<Enter>", lambda e: self.editor.config(cursor="hand2"))
        self.editor.tag_bind(tagname, "<Leave>", lambda e: self.editor.config(cursor="xterm"))

    # ---------------- 액션들 ----------------
    def toggle_inline(self, tagname):
        try:
            start = self.editor.index("sel.first")
            end = self.editor.index("sel.last")
        except tk.TclError:
            self.show_alert("Select text first bruh")
            return
        ranges = self.editor.tag_ranges(tagname)
        already = False
        # 선택 구간 전체가 이미 그 태그를 갖고 있는지 대략적으로 확인
        if tagname in self.editor.tag_names("sel.first"):
            already = True
        if already:
            self.editor.tag_remove(tagname, start, end)
        else:
            self.editor.tag_add(tagname, start, end)
        self.mark_unsaved()
        self.refresh_toolbar_state()

    def refresh_toolbar_state(self):
        def is_active(tag):
            return tag in self.editor.tag_names("insert")
        self.bold_btn.config(relief="sunken" if is_active("bold") else "raised")
        self.italic_btn.config(relief="sunken" if is_active("italic") else "raised")
        self.underline_btn.config(relief="sunken" if is_active("underline") else "raised")
        self.strike_btn.config(relief="sunken" if is_active("overstrike") else "raised")
        self.update_status()

    def select_all_text(self):
        self.editor.tag_add("sel", "1.0", "end-1c")
        self.editor.focus_set()

    def do_undo(self):
        try:
            self.editor.edit_undo()
        except tk.TclError:
            pass
        self.update_status()

    def do_redo(self):
        try:
            self.editor.edit_redo()
        except tk.TclError:
            pass
        self.update_status()

    # ---------------- 파일: 새로 만들기 / 열기 / 저장 ----------------
    def reset_editor(self):
        self.editor.delete("1.0", "end")
        self.images.clear()
        self.selected_image_id = None
        self.current_file_name = None
        self.current_file_path = None
        self.unsaved = False
        self.update_status()
        self.title_update()
        self.save_autosave_now()

    def do_new(self):
        self.confirm_discard(self.reset_editor)

    def confirm_discard(self, proceed_cb):
        if not self.unsaved:
            proceed_cb()
            return
        win = tk.Toplevel(self.root)
        win.title("Hold up!")
        win.configure(bg=GRAY)
        win.transient(self.root)
        win.grab_set()
        tk.Label(win, text="Do u rlly want 2 trash ur unsaved text??", bg=GRAY, padx=20, pady=14).pack()
        btns = tk.Frame(win, bg=GRAY)
        btns.pack(pady=(0, 14))

        def ye():
            win.destroy()
            proceed_cb()

        def nuhuh():
            win.destroy()
            self.do_save()
            proceed_cb()

        tk.Button(btns, text="Ye", width=10, command=ye).pack(side="left", padx=6)
        tk.Button(btns, text="Nuh uh", width=10, command=nuhuh).pack(side="left", padx=6)

    def do_open(self):
        path = filedialog.askopenfilename(filetypes=[("Text/HTML", "*.html *.htm *.txt"), ("All files", "*.*")])
        if not path:
            return
        with open(path, "r", encoding="utf-8", errors="replace") as f:
            data = f.read()
        self.editor.delete("1.0", "end")
        self.images.clear()
        name_lower = path.lower()
        if name_lower.endswith(".txt"):
            self.editor.insert("1.0", data)
        else:
            m = re.search(r'<div id="editor"[^>]*>([\s\S]*?)</div>\s*</body>', data, re.IGNORECASE)
            html_body = m.group(1) if m else data
            self._load_html_into_editor(html_body)
        self.current_file_name = os.path.basename(path)
        self.current_file_path = path
        self.unsaved = False
        self.update_status()
        self.title_update()
        self.save_autosave_now()

    def do_save(self):
        # 이미 저장해본 경로가 있으면 그 경로에 바로 덮어씀 (매번 다시 안 물어봄)
        if self.current_file_path:
            self._write_to_path(self.current_file_path)
        else:
            self.do_save_as()

    def do_save_as(self):
        name = simpledialog.askstring("Save as", "Name da file bru (Ex: Memo.txt)",
                                       initialvalue=self.current_file_name or "Untitled.txt")
        if not name:
            return
        # txt로만 저장 (서식/이미지는 저장되지 않고 순수 텍스트만 저장됨)
        base, _ext = os.path.splitext(name)
        name = base + ".txt"
        path = filedialog.asksaveasfilename(initialfile=name, defaultextension=".txt",
                                             filetypes=[("Text file", "*.txt"), ("All files", "*.*")])
        if not path:
            return
        self.current_file_name = os.path.basename(path)
        self.current_file_path = path
        self._write_to_path(path)
        self.title_update()

    def _write_to_path(self, path):
        plain_text = self.editor.get("1.0", "end-1c")
        with open(path, "w", encoding="utf-8") as f:
            f.write(plain_text)
        self.unsaved = False
        self.title_update()
        if any(k.startswith("img") for k in self.images):
            self.show_alert("File saved lol (근데 txt라서 이미지/서식은 저장 안 됨)", "Saved")
        else:
            self.show_alert("File saved lol", "Saved")

    # ---------------- HTML 내보내기 / 불러오기 ----------------
    def export_html(self):
        """에디터 내용을 (거의) 원본과 같은 형식의 인라인 HTML로 직렬화."""
        parts = []
        open_tags = {"bold": False, "italic": False, "underline": False, "overstrike": False}
        tagorder = ["bold", "italic", "underline", "overstrike"]
        tagmap = {"bold": "b", "italic": "i", "underline": "u", "overstrike": "s"}

        def close_all():
            for t in reversed(tagorder):
                if open_tags[t]:
                    parts.append(f"</{tagmap[t]}>")
                    open_tags[t] = False

        def sync_tags(active):
            # 닫아야 할 것부터 역순으로 닫고, 새로 열 것은 순서대로 연다 (중첩 유지)
            for t in reversed(tagorder):
                if open_tags[t] and t not in active:
                    parts.append(f"</{tagmap[t]}>")
                    open_tags[t] = False
            for t in tagorder:
                if t in active and not open_tags[t]:
                    parts.append(f"<{tagmap[t]}>")
                    open_tags[t] = True

        dump = self.editor.dump("1.0", "end-1c", tag=True, text=True, image=True)
        active = set()
        for key, value, index in dump:
            if key == "tagon" and value in tagorder:
                active.add(value)
            elif key == "tagoff" and value in tagorder:
                active.discard(value)
            elif key == "text":
                sync_tags(active)
                escaped = (value.replace("&", "&amp;").replace("<", "&lt;")
                           .replace(">", "&gt;").replace("\n", "<br>"))
                parts.append(escaped)
            elif key == "image":
                img_id = value
                if img_id in self.images:
                    b64 = self._pil_to_base64(self.images[img_id]["pil"])
                    w, h = self.images[img_id]["pil"].size
                    parts.append(f'<img src="data:image/png;base64,{b64}" style="width:{w}px;height:{h}px;">')
        close_all()
        return "".join(parts)

    def _pil_to_base64(self, pil_img):
        buf = io.BytesIO()
        pil_img.save(buf, format="PNG")
        return base64.b64encode(buf.getvalue()).decode("ascii")

    def _load_html_into_editor(self, html_fragment):
        parser = _SimpleHTMLImporter(self)
        parser.feed(html_fragment)

    def insert_plain_text(self, text, style):
        tags = []
        if style.get("bold"):
            tags.append("bold")
        if style.get("italic"):
            tags.append("italic")
        if style.get("underline"):
            tags.append("underline")
        if style.get("strike"):
            tags.append("overstrike")
        self.editor.insert("end", text, tuple(tags))

    def insert_image_from_src(self, src):
        try:
            if src.startswith("data:image"):
                b64data = src.split(",", 1)[1]
                raw = base64.b64decode(b64data)
                pil_img = Image.open(io.BytesIO(raw)).convert("RGBA")
            else:
                pil_img = Image.open(src).convert("RGBA")
        except Exception:
            return
        self._insert_pil_image(pil_img, at_cursor=False)

    # ---------------- 이미지 ----------------
    def insert_image_dialog(self):
        path = filedialog.askopenfilename(filetypes=[("Images", "*.png *.jpg *.jpeg *.gif *.bmp *.webp")])
        if not path:
            return
        try:
            pil_img = Image.open(path).convert("RGBA")
        except Exception as e:
            self.show_alert(f"이미지를 열 수 없음: {e}", "Error")
            return
        self._insert_pil_image(pil_img, at_cursor=True)

    def _insert_pil_image(self, pil_img, at_cursor=True):
        # 원본처럼 최대 폭 400px 로 제한
        display_img = pil_img.copy()
        if display_img.width > 400:
            ratio = 400 / display_img.width
            display_img = display_img.resize((400, max(1, int(display_img.height * ratio))), Image.LANCZOS)
        photo = ImageTk.PhotoImage(display_img)

        self._img_counter += 1
        img_id = f"img{self._img_counter}"

        self.editor.focus_set()
        if at_cursor:
            index = self.editor.index("insert")
        else:
            index = "end"
        self.editor.image_create(index, image=photo, name=img_id)
        self.images[img_id] = {"pil": pil_img, "display": display_img, "photo": photo}

        tagname = f"imgtag_{img_id}"
        start = self.editor.index(index) if at_cursor else self.editor.index("end - 2c")
        end = f"{start} + 1c"
        self.editor.tag_add(tagname, start, end)
        self.editor.tag_bind(tagname, "<Button-1>", lambda e, iid=img_id: self.select_image(iid))

        self.mark_unsaved()
        self.update_status()

    def select_image(self, img_id):
        self.selected_image_id = img_id
        self.update_status()

    def _deselect_image(self):
        if self.selected_image_id:
            self.selected_image_id = None
            self.update_status()

    def _on_editor_click_release(self, event):
        # 이미지 위를 클릭한 경우는 select_image()가 이미 처리했으니 여기서 다시
        # 풀어버리면 안 됨 -- 진짜로 이미지가 아닌 곳을 클릭했을 때만 선택 해제
        self.update_status()
        try:
            idx = self.editor.index(f"@{event.x},{event.y}")
        except tk.TclError:
            return
        tags_here = self.editor.tag_names(idx)
        if not any(t.startswith("imgtag_") for t in tags_here):
            self._deselect_image()

    def open_image_resize(self):
        if not self.selected_image_id:
            self.show_alert("Click da image first bruh")
            return
        info = self.images[self.selected_image_id]
        cur_w, cur_h = info["display"].size

        win = tk.Toplevel(self.root)
        win.title("Resize image")
        win.configure(bg=GRAY)
        win.transient(self.root)
        win.grab_set()
        tk.Label(win, text="Width(px):", bg=GRAY).grid(row=0, column=0, sticky="w", padx=10, pady=(10, 2))
        w_var = tk.IntVar(value=cur_w)
        tk.Entry(win, textvariable=w_var).grid(row=1, column=0, padx=10)
        tk.Label(win, text="Height(px):", bg=GRAY).grid(row=2, column=0, sticky="w", padx=10, pady=(8, 2))
        h_var = tk.IntVar(value=cur_h)
        tk.Entry(win, textvariable=h_var).grid(row=3, column=0, padx=10)
        keep_ratio = tk.BooleanVar(value=True)
        tk.Checkbutton(win, text="Keep aspect ratio", variable=keep_ratio, bg=GRAY).grid(
            row=4, column=0, sticky="w", padx=10, pady=8)

        ratio = info["pil"].height / info["pil"].width
        syncing = {"on": False}  # w<->h가 서로를 무한히 갱신하는 걸 막는 재진입 방지 플래그

        def w_changed(*_):
            if syncing["on"] or not keep_ratio.get():
                return
            try:
                syncing["on"] = True
                h_var.set(round(w_var.get() * ratio))
            except Exception:
                pass
            finally:
                syncing["on"] = False

        def h_changed(*_):
            if syncing["on"] or not keep_ratio.get():
                return
            try:
                syncing["on"] = True
                w_var.set(round(h_var.get() / ratio))
            except Exception:
                pass
            finally:
                syncing["on"] = False

        w_var.trace_add("write", w_changed)
        h_var.trace_add("write", h_changed)

        def apply():
            w = clamp(w_var.get(), 10, 4000)
            h = clamp(h_var.get(), 10, 4000)
            new_display = info["pil"].resize((w, h), Image.LANCZOS)
            new_photo = ImageTk.PhotoImage(new_display)
            info["display"] = new_display
            info["photo"] = new_photo
            self.editor.image_configure(self.selected_image_id, image=new_photo)
            self.mark_unsaved()
            win.destroy()

        btns = tk.Frame(win, bg=GRAY)
        btns.grid(row=5, column=0, pady=(0, 10))
        tk.Button(btns, text="Apply", command=apply).pack(side="left", padx=6)
        tk.Button(btns, text="Cancel", command=win.destroy).pack(side="left", padx=6)

    # ---------------- 폰트 ----------------
    def open_font_list(self):
        win = tk.Toplevel(self.root)
        win.title("Change font")
        win.configure(bg=GRAY)
        win.transient(self.root)
        win.grab_set()
        lb = tk.Listbox(win, height=10, width=30)
        lb.pack(padx=10, pady=10)
        for i, f in enumerate(AVAILABLE_FONTS):
            lb.insert("end", f)
            if f == self.font_family:
                lb.selection_set(i)

        def apply():
            sel = lb.curselection()
            if sel:
                self.font_family = AVAILABLE_FONTS[sel[0]]
                self.editor.configure(font=(self.font_family, self.font_size_px))
                self.mark_unsaved()
            win.destroy()

        btns = tk.Frame(win, bg=GRAY)
        btns.pack(pady=(0, 10))
        tk.Button(btns, text="Apply", command=apply).pack(side="left", padx=6)
        tk.Button(btns, text="Cancel", command=win.destroy).pack(side="left", padx=6)

    def open_font_size(self):
        win = tk.Toplevel(self.root)
        win.title("Set text size")
        win.configure(bg=GRAY)
        win.transient(self.root)
        win.grab_set()
        tk.Label(win, text="Applies to the selected text, or the whole document if nothing's selected.",
                 bg=GRAY, fg=DARK_GRAY, wraplength=260, font=("Malgun Gothic", 8)).pack(padx=10, pady=(10, 4))
        tk.Label(win, text="Text size(px):", bg=GRAY).pack(anchor="w", padx=10)
        size_var = tk.IntVar(value=self.font_size_px)
        tk.Entry(win, textvariable=size_var).pack(padx=10, fill="x")

        def apply():
            try:
                px = clamp(int(size_var.get()), 6, 200)
            except Exception:
                self.show_alert("Numbers only lol", "Error")
                return
            try:
                start = self.editor.index("sel.first")
                end = self.editor.index("sel.last")
                had_sel = True
            except tk.TclError:
                had_sel = False
            if had_sel:
                tagname = f"size_{px}"
                self.editor.tag_configure(tagname, font=(self.font_family, px))
                self.editor.tag_add(tagname, start, end)
            else:
                self.font_size_px = px
                self.editor.configure(font=(self.font_family, px))
            self.mark_unsaved()
            win.destroy()

        btns = tk.Frame(win, bg=GRAY)
        btns.pack(pady=10)
        tk.Button(btns, text="Apply", command=apply).pack(side="left", padx=6)
        tk.Button(btns, text="Cancel", command=win.destroy).pack(side="left", padx=6)

    # ---------------- 색상 ----------------
    def _pick_color(self, default):
        from tkinter import colorchooser
        color = colorchooser.askcolor(color=default, parent=self.root, title="Pick a color")
        return color[1] if color and color[1] else None

    def change_bg_color(self):
        color = self._pick_color("#ffffff")
        if color:
            self.editor.configure(bg=color)
            self.dark_mode = False
            self.mark_unsaved()

    def change_text_color(self):
        try:
            start = self.editor.index("sel.first")
            end = self.editor.index("sel.last")
        except tk.TclError:
            self.show_alert("Select text 2 color first bruh")
            return
        color = self._pick_color("#000000")
        if color:
            tagname = f"fg_{color}"
            self.editor.tag_configure(tagname, foreground=color)
            self.editor.tag_add(tagname, start, end)
            self.mark_unsaved()

    def change_border_color(self):
        color = self._pick_color(self.border_color)
        if color:
            self.border_color = color
            self.editor_border.configure(bg=color)
            self.mark_unsaved()

    def toggle_dark_mode(self):
        self.dark_mode = not self.dark_mode
        if self.dark_mode:
            self.editor.configure(bg="#1E1E1E", fg="#E0E0E0", insertbackground="#E0E0E0")
        else:
            self.editor.configure(bg="white", fg="black", insertbackground="black")
        self.mark_unsaved()

    # ---------------- 그림판 ----------------
    def open_paint(self):
        if self.paint_window is not None and self.paint_window.winfo_exists():
            self.paint_window.lift()
            self.paint_window.focus_set()
            return
        self.paint_window = PaintWindow(self.root, self)

    def insert_finished_painting(self, pil_img):
        """Paint 창의 '문서에 삽입' 결과를 받는 콜백."""
        self._insert_pil_image(pil_img.convert("RGBA"), at_cursor=True)

    # ---------------- 알림 모달 ----------------
    def show_alert(self, msg, title="Notice"):
        win = tk.Toplevel(self.root)
        win.title(title)
        win.configure(bg=GRAY)
        win.transient(self.root)
        win.grab_set()
        tk.Label(win, text=msg, bg=GRAY, padx=20, pady=14, wraplength=260).pack()
        tk.Button(win, text="Ok", command=win.destroy, width=10).pack(pady=(0, 14))

    # ---------------- 자동 저장 ----------------
    def _schedule_autosave(self):
        if self._autosave_job:
            self.root.after_cancel(self._autosave_job)
        self._autosave_job = self.root.after(1200, self.save_autosave_now)

    def save_autosave_now(self):
        try:
            data = {
                "html": self.export_html(),
                "fontFamily": self.font_family,
                "fontSizePx": self.font_size_px,
                "fileName": self.current_file_name,
            }
            with open(AUTOSAVE_FILE, "w", encoding="utf-8") as f:
                json.dump(data, f)
        except Exception:
            pass

    def _try_restore_autosave(self):
        if not os.path.exists(AUTOSAVE_FILE):
            return
        try:
            with open(AUTOSAVE_FILE, "r", encoding="utf-8") as f:
                data = json.load(f)
        except Exception:
            return
        if not data.get("html"):
            return
        if messagebox.askyesno("Unsaved work found",
                                "Found something you were working on before. Restore it?"):
            self.font_family = data.get("fontFamily", self.font_family)
            self.font_size_px = data.get("fontSizePx", self.font_size_px)
            self.editor.configure(font=(self.font_family, self.font_size_px))
            self._load_html_into_editor(data["html"])
            self.current_file_name = data.get("fileName")
            self.title_update()
        else:
            try:
                os.remove(AUTOSAVE_FILE)
            except Exception:
                pass

    def _on_close(self):
        self.save_autosave_now()
        if self.unsaved:
            if not messagebox.askyesno("Quit", "You have unsaved changes. Quit anyway?"):
                return
        self.root.destroy()


# ----------------------------------------------------------------------------
# 그림판 (Paint)
# ----------------------------------------------------------------------------
class Layer:
    def __init__(self, name, width, height):
        self.name = name
        self.image = Image.new("RGBA", (width, height), (0, 0, 0, 0))
        self.visible = True
        self.alpha_locked = False


class PaintWindow(tk.Toplevel):
    def __init__(self, master, notepad, width=1920, height=1080):
        super().__init__(master)
        self.notepad = notepad
        self.title("Paint")
        self.configure(bg=GRAY)
        self.geometry("1000x680")

        self.canvas_w = width
        self.canvas_h = height
        self.layers = [Layer("Layer 1", width, height)]
        self.active_index = 0
        self.zoom = 1.0
        self.tool = "brush"
        self.brush_size = 8
        self.color = "#000000"
        self.history = []
        self.redo_stack = []
        self.selection = None       # {'image':PIL RGBA same size as canvas, 'bbox':(x0,y0,x1,y1)}
        self.lasso_points = []
        self.drag_start = None
        self.selection_drag_origin = None
        self._is_fullscreen = False
        self.photo_ref = None
        self.opacity_pct = 100
        # 색상 피커 같은 네이티브 모달이 떠 있는 동안은 Paint 자체 단축키(특히 Escape)가
        # 같이 반응해서 창이 꺼져버리는 버그가 있었음 -> 모달 여는 동안엔 단축키 무시
        self._shortcuts_suspended = False

        self._build_ui()
        self._bind_events()
        self.set_tool("brush")
        # 1920x1080 같은 큰 캔버스가 화면보다 크면 다 보이게 축소해서 시작
        # (창이 실제로 화면에 배치된 뒤에 크기를 알 수 있으므로 살짝 지연)
        self.after(50, self._fit_zoom_to_view)
        self.render()

    # ---------------- UI ----------------
    def _build_ui(self):
        self.title("Paint")

        toolbar = tk.Frame(self, bg=GRAY)
        toolbar.pack(fill="x")
        tk.Button(toolbar, text="\u21b6 Undo", command=self.undo).pack(side="left", padx=2, pady=3)
        tk.Button(toolbar, text="\u21b7 Redo", command=self.redo).pack(side="left", padx=2, pady=3)

        self.tool_buttons = {}
        tools = [("brush", "Brush (B)"), ("eraser", "Eraser (E)"), ("eyedropper", "Eyedropper (P)"),
                 ("lasso", "Lasso Move (M)"), ("lasso-fill", "Lasso Fill (G)"), ("lasso-erase", "Lasso Erase (D)")]
        for key, label in tools:
            b = tk.Button(toolbar, text=label, command=lambda k=key: self.set_tool(k))
            b.pack(side="left", padx=2, pady=3)
            self.tool_buttons[key] = b

        tk.Label(toolbar, text="Size:", bg=GRAY).pack(side="left", padx=(10, 2))
        self.size_var = tk.IntVar(value=self.brush_size)
        tk.Spinbox(toolbar, from_=1, to=200, width=5, textvariable=self.size_var,
                   command=self._on_size_change).pack(side="left")
        self.size_var.trace_add("write", lambda *_: self._on_size_change())

        tk.Label(toolbar, text="Color:", bg=GRAY).pack(side="left", padx=(10, 2))
        self.color_swatch = tk.Button(toolbar, bg=self.color, width=3, command=self.pick_color)
        self.color_swatch.pack(side="left")

        tk.Label(toolbar, text="Opacity%:", bg=GRAY).pack(side="left", padx=(10, 2))
        self.opacity_var = tk.IntVar(value=self.opacity_pct)
        tk.Spinbox(toolbar, from_=1, to=100, width=5, textvariable=self.opacity_var,
                   command=self._on_opacity_change).pack(side="left")
        self.opacity_var.trace_add("write", lambda *_: self._on_opacity_change())

        tk.Button(toolbar, text="Clear layer", command=self.clear_active_layer).pack(side="left", padx=(10, 2))
        tk.Button(toolbar, text="New canvas", command=self.open_new_canvas_dialog).pack(side="left", padx=(12, 2))
        tk.Button(toolbar, text="Zoom -", command=self.zoom_out).pack(side="left", padx=(12, 2))
        tk.Button(toolbar, text="Reset", command=self.zoom_reset).pack(side="left", padx=2)
        tk.Button(toolbar, text="Zoom +", command=self.zoom_in).pack(side="left", padx=2)
        self.fs_btn = tk.Button(toolbar, text="Fullscreen", command=self.toggle_fullscreen)
        self.fs_btn.pack(side="right", padx=(2, 6))

        # 하단 버튼 줄을 body(캔버스+레이어패널, expand=True)보다 먼저 배치해야
        # pack() 배분 순서상 공간이 안 잘리고 남음 (메모장 상태바랑 같은 이유의 버그)
        bottom = tk.Frame(self, bg=GRAY)
        bottom.pack(fill="x", side="bottom")
        tk.Button(bottom, text="Cancel", command=self.close).pack(side="right", padx=6, pady=6)
        tk.Button(bottom, text="Insert into document", command=self.insert_into_document).pack(side="right", padx=6, pady=6)

        body = tk.Frame(self)
        body.pack(fill="both", expand=True)

        canvas_area = tk.Frame(body, bg="#7a7a7a")
        canvas_area.pack(side="left", fill="both", expand=True)
        self.hbar = tk.Scrollbar(canvas_area, orient="horizontal")
        self.vbar = tk.Scrollbar(canvas_area, orient="vertical")
        self.canvas = tk.Canvas(canvas_area, bg="#7a7a7a",
                                 xscrollcommand=self.hbar.set, yscrollcommand=self.vbar.set)
        self.hbar.config(command=self.canvas.xview)
        self.vbar.config(command=self.canvas.yview)
        self.hbar.pack(side="bottom", fill="x")
        self.vbar.pack(side="right", fill="y")
        self.canvas.pack(side="left", fill="both", expand=True)
        self.canvas_image_id = self.canvas.create_image(0, 0, anchor="nw")

        layer_panel = tk.Frame(body, width=200, bg=GRAY)
        layer_panel.pack(side="right", fill="y")
        layer_panel.pack_propagate(False)
        tk.Label(layer_panel, text="Layers", bg=GRAY, font=("Malgun Gothic", 10, "bold")).pack(anchor="w", padx=6, pady=4)
        self.layer_list_frame = tk.Frame(layer_panel, bg=GRAY)
        self.layer_list_frame.pack(fill="both", expand=True, padx=4)

        btns1 = tk.Frame(layer_panel, bg=GRAY)
        btns1.pack(fill="x", padx=4, pady=2)
        tk.Button(btns1, text="Add", command=self.add_layer, width=6).pack(side="left")
        tk.Button(btns1, text="Dup", command=self.duplicate_layer, width=6).pack(side="left")
        tk.Button(btns1, text="Del", command=self.delete_layer, width=6).pack(side="left")
        btns2 = tk.Frame(layer_panel, bg=GRAY)
        btns2.pack(fill="x", padx=4, pady=2)
        tk.Button(btns2, text="Merge\u2193", command=self.merge_down, width=6).pack(side="left")
        tk.Button(btns2, text="\u2191", command=self.move_layer_up, width=3).pack(side="left")
        tk.Button(btns2, text="\u2193", command=self.move_layer_down, width=3).pack(side="left")

        self.render_layer_list()

    def _bind_events(self):
        self.canvas.bind("<ButtonPress-1>", self.on_canvas_down)
        self.canvas.bind("<B1-Motion>", self.on_canvas_drag)
        self.canvas.bind("<ButtonRelease-1>", self.on_canvas_up)
        self.bind("<Key>", self.on_key)
        self.protocol("WM_DELETE_WINDOW", self.close)

    # ---------------- 도구 ----------------
    def set_tool(self, tool):
        self.tool = tool
        self.lasso_points = []
        for key, btn in self.tool_buttons.items():
            btn.config(relief="sunken" if key == tool else "raised")

    def _on_size_change(self):
        try:
            self.brush_size = max(1, int(self.size_var.get()))
        except Exception:
            pass

    def _on_opacity_change(self):
        try:
            self.opacity_pct = clamp(int(self.opacity_var.get()), 1, 100)
        except Exception:
            pass

    def pick_color(self):
        from tkinter import colorchooser
        self._shortcuts_suspended = True
        try:
            c = colorchooser.askcolor(color=self.color, parent=self, title="Pick a color")
        finally:
            self._shortcuts_suspended = False
        if c and c[1]:
            self.color = c[1]
            self.color_swatch.config(bg=self.color)

    # ---------------- 좌표 변환 ----------------
    def _canvas_to_image_xy(self, event):
        cx = self.canvas.canvasx(event.x)
        cy = self.canvas.canvasy(event.y)
        return cx / self.zoom, cy / self.zoom

    # ---------------- 그리기 ----------------
    def push_history(self):
        snap = [(l.name, l.image.copy(), l.visible, l.alpha_locked) for l in self.layers]
        self.history.append((snap, self.active_index))
        if len(self.history) > 40:
            self.history.pop(0)
        self.redo_stack.clear()
        self.update_undo_redo_buttons()

    def undo(self):
        if not self.history:
            return
        cur_snap = [(l.name, l.image.copy(), l.visible, l.alpha_locked) for l in self.layers]
        self.redo_stack.append((cur_snap, self.active_index))
        snap, idx = self.history.pop()
        self._restore_snapshot(snap, idx)
        self.update_undo_redo_buttons()

    def redo(self):
        if not self.redo_stack:
            return
        cur_snap = [(l.name, l.image.copy(), l.visible, l.alpha_locked) for l in self.layers]
        self.history.append((cur_snap, self.active_index))
        snap, idx = self.redo_stack.pop()
        self._restore_snapshot(snap, idx)
        self.update_undo_redo_buttons()

    def _restore_snapshot(self, snap, idx):
        self.layers = []
        for name, img, vis, lock in snap:
            l = Layer(name, img.width, img.height)
            l.image = img
            l.visible = vis
            l.alpha_locked = lock
            self.layers.append(l)
        self.active_index = min(idx, len(self.layers) - 1)
        self.canvas_w, self.canvas_h = self.layers[0].image.size
        self.render_layer_list()
        self.render()

    def update_undo_redo_buttons(self):
        pass  # 버튼 활성/비활성은 생략(항상 클릭 가능, 스택 비어있으면 그냥 무시)

    def on_canvas_down(self, event):
        x, y = self._canvas_to_image_xy(event)
        if self.tool in ("brush", "eraser"):
            self.push_history()
            self.drag_start = (x, y)
            self._stroke_point(x, y)
            self.render()
        elif self.tool == "eyedropper":
            self._eyedrop(x, y)
        elif self.tool in ("lasso", "lasso-fill", "lasso-erase"):
            if self.selection is not None and self.tool == "lasso":
                # 이미 떠 있는 선택 영역을 드래그로 옮기기 시작
                self.selection_drag_origin = (x, y)
            else:
                self.lasso_points = [(x, y)]

    def on_canvas_drag(self, event):
        x, y = self._canvas_to_image_xy(event)
        if self.tool in ("brush", "eraser"):
            self._stroke_point(x, y)
            self.render()
        elif self.tool in ("lasso", "lasso-fill", "lasso-erase"):
            if self.selection is not None and self.selection_drag_origin is not None and self.tool == "lasso":
                dx = x - self.selection_drag_origin[0]
                dy = y - self.selection_drag_origin[1]
                self.selection["x"] += dx
                self.selection["y"] += dy
                self.selection_drag_origin = (x, y)
                self.render()
            else:
                self.lasso_points.append((x, y))
                self.render(preview_lasso=True)

    def on_canvas_up(self, event):
        if self.tool in ("brush", "eraser"):
            self.drag_start = None
            self.notepad.mark_unsaved()
        elif self.tool == "lasso":
            if self.selection is not None and self.selection_drag_origin is not None:
                self._commit_selection()
                self.selection_drag_origin = None
            elif len(self.lasso_points) >= 3:
                self.push_history()
                self._cut_lasso_selection()
        elif self.tool == "lasso-fill":
            if len(self.lasso_points) >= 3:
                self.push_history()
                self._fill_lasso(self.color)
        elif self.tool == "lasso-erase":
            if len(self.lasso_points) >= 3:
                self.push_history()
                self._fill_lasso((0, 0, 0, 0))
        self.render()

    def _stroke_point(self, x, y):
        """브러시/지우개 한 구간을 그림. 불투명도(opacity)와 알파잠금(alpha lock)을
        원본(JS Canvas의 globalAlpha / source-atop / destination-out)과 비슷하게 재현."""
        layer = self.layers[self.active_index]
        r = self.brush_size / 2
        p0 = self.drag_start if self.drag_start else (x, y)
        p1 = (x, y)

        # 이번 구간이 차지하는 영역만 잘라서 작업 (전체 캔버스에 매번 합성하면 느림)
        pad = r + 2
        bx0 = clamp(int(min(p0[0], p1[0]) - pad), 0, self.canvas_w)
        by0 = clamp(int(min(p0[1], p1[1]) - pad), 0, self.canvas_h)
        bx1 = clamp(int(max(p0[0], p1[0]) + pad) + 1, 0, self.canvas_w)
        by1 = clamp(int(max(p0[1], p1[1]) + pad) + 1, 0, self.canvas_h)
        self.drag_start = (x, y)
        if bx1 <= bx0 or by1 <= by0:
            return

        ox, oy = bx0, by0
        w, h = bx1 - bx0, by1 - by0

        # 브러시 모양(원+선)을 흑백 마스크로 그리기
        shape_mask = Image.new("L", (w, h), 0)
        sd = ImageDraw.Draw(shape_mask)
        lp0 = (p0[0] - ox, p0[1] - oy)
        lp1 = (p1[0] - ox, p1[1] - oy)
        if lp0 != lp1:
            sd.line([lp0, lp1], fill=255, width=self.brush_size)
        sd.ellipse([lp1[0] - r, lp1[1] - r, lp1[0] + r, lp1[1] + r], fill=255)
        sd.ellipse([lp0[0] - r, lp0[1] - r, lp0[0] + r, lp0[1] + r], fill=255)

        opacity = self.opacity_pct / 100.0
        if opacity < 1.0:
            shape_mask = shape_mask.point(lambda v: int(v * opacity))

        region = layer.image.crop((bx0, by0, bx1, by1))

        if layer.alpha_locked:
            existing_alpha = region.split()[3]
            existing_mask = existing_alpha.point(lambda v: 255 if v > 0 else 0)
            shape_mask = ImageChops.multiply(shape_mask, existing_mask)

        if self.tool == "eraser":
            transparent = Image.new("RGBA", (w, h), (0, 0, 0, 0))
            region.paste(transparent, (0, 0), shape_mask)
        else:
            rgba = self._hex_to_rgba(self.color, 255)
            colored = Image.new("RGBA", (w, h), rgba)
            region.paste(colored, (0, 0), shape_mask)

        layer.image.paste(region, (bx0, by0))

    def _hex_to_rgba(self, hexcolor, alpha=255):
        hexcolor = hexcolor.lstrip("#")
        r = int(hexcolor[0:2], 16)
        g = int(hexcolor[2:4], 16)
        b = int(hexcolor[4:6], 16)
        return (r, g, b, alpha)

    def _eyedrop(self, x, y):
        composite = self._composite_transparent()
        xi, yi = int(x), int(y)
        if 0 <= xi < composite.width and 0 <= yi < composite.height:
            r, g, b, a = composite.getpixel((xi, yi))
            self.color = f"#{r:02x}{g:02x}{b:02x}"
            self.color_swatch.config(bg=self.color)
        # 원본처럼: 색을 찍으면 자동으로 브러시 도구로 돌아감
        self.set_tool("brush")

    def _lasso_mask(self):
        mask = Image.new("L", (self.canvas_w, self.canvas_h), 0)
        ImageDraw.Draw(mask).polygon(self.lasso_points, fill=255)
        return mask

    def _fill_lasso(self, fillcolor):
        layer = self.layers[self.active_index]
        mask = self._lasso_mask()
        if layer.alpha_locked:
            # 브러시랑 똑같이: 알파 잠금 켜져 있으면 이미 칠해진(불투명) 픽셀 위에만 적용
            existing_alpha = layer.image.split()[3]
            existing_mask = existing_alpha.point(lambda v: 255 if v > 0 else 0)
            mask = ImageChops.multiply(mask, existing_mask)
        color_img = Image.new("RGBA", layer.image.size,
                               self._hex_to_rgba(fillcolor) if isinstance(fillcolor, str) else fillcolor)
        layer.image.paste(color_img, (0, 0), mask)
        self.lasso_points = []
        self.notepad.mark_unsaved()

    def _cut_lasso_selection(self):
        layer = self.layers[self.active_index]
        mask = self._lasso_mask()
        cut_full = Image.new("RGBA", layer.image.size, (0, 0, 0, 0))
        cut_full.paste(layer.image, (0, 0), mask)
        # 원래 레이어에서는 지움 (선택한 영역만 투명하게)
        empty = Image.new("RGBA", layer.image.size, (0, 0, 0, 0))
        layer.image.paste(empty, (0, 0), mask)

        xs = [p[0] for p in self.lasso_points]
        ys = [p[1] for p in self.lasso_points]
        x0 = clamp(int(min(xs)), 0, self.canvas_w)
        y0 = clamp(int(min(ys)), 0, self.canvas_h)
        x1 = clamp(int(max(xs)) + 1, 0, self.canvas_w)
        y1 = clamp(int(max(ys)) + 1, 0, self.canvas_h)
        if x1 <= x0 or y1 <= y0:
            self.lasso_points = []
            return
        crop = cut_full.crop((x0, y0, x1, y1))
        self.selection = {"crop": crop, "x": x0, "y": y0}
        self.lasso_points = []
        self.notepad.mark_unsaved()

    def _commit_selection(self):
        if not self.selection:
            return
        self.push_history()
        layer = self.layers[self.active_index]
        crop = self.selection["crop"]
        layer.image.paste(crop, (int(round(self.selection["x"])), int(round(self.selection["y"]))), crop)
        self.selection = None
        self.notepad.mark_unsaved()

    # ---------------- 레이어 ----------------
    def render_layer_list(self):
        for w in self.layer_list_frame.winfo_children():
            w.destroy()
        for i in range(len(self.layers) - 1, -1, -1):
            layer = self.layers[i]
            row = tk.Frame(self.layer_list_frame, bg="#a8a8ff" if i == self.active_index else "white",
                            bd=1, relief="sunken")
            row.pack(fill="x", pady=1)
            vis_var = tk.BooleanVar(value=layer.visible)

            def toggle_vis(i=i, var=None):
                self.layers[i].visible = not self.layers[i].visible
                self.render_layer_list()
                self.render()

            tk.Checkbutton(row, variable=vis_var, command=lambda i=i: toggle_vis(i), bg=row["bg"],
                           selectcolor="white").pack(side="left")
            lbl = tk.Label(row, text=layer.name, bg=row["bg"], anchor="w")
            lbl.pack(side="left", fill="x", expand=True)
            lbl.bind("<Button-1>", lambda e, i=i: self._select_layer(i))
            row.bind("<Button-1>", lambda e, i=i: self._select_layer(i))

            lock_var = tk.BooleanVar(value=layer.alpha_locked)

            def toggle_lock(i=i):
                self.layers[i].alpha_locked = not self.layers[i].alpha_locked
                self.render_layer_list()

            tk.Checkbutton(row, text="\U0001F512", variable=lock_var, command=lambda i=i: toggle_lock(i),
                           bg=row["bg"], selectcolor="white").pack(side="right")

    def _select_layer(self, i):
        self.active_index = i
        self.render_layer_list()

    def add_layer(self):
        self.push_history()
        self.layers.append(Layer(f"Layer {len(self.layers) + 1}", self.canvas_w, self.canvas_h))
        self.active_index = len(self.layers) - 1
        self.render_layer_list()
        self.render()

    def delete_layer(self):
        if len(self.layers) <= 1:
            return
        self.push_history()
        self.layers.pop(self.active_index)
        self.active_index = max(0, self.active_index - 1)
        self.render_layer_list()
        self.render()

    def duplicate_layer(self):
        self.push_history()
        src = self.layers[self.active_index]
        dup = Layer(src.name + " copy", self.canvas_w, self.canvas_h)
        dup.image = src.image.copy()
        dup.visible = src.visible
        dup.alpha_locked = src.alpha_locked
        self.layers.insert(self.active_index + 1, dup)
        self.active_index += 1
        self.render_layer_list()
        self.render()

    def merge_down(self):
        if self.active_index <= 0:
            return
        self.push_history()
        below = self.layers[self.active_index - 1]
        below.image = Image.alpha_composite(below.image, self.layers[self.active_index].image)
        self.layers.pop(self.active_index)
        self.active_index -= 1
        self.render_layer_list()
        self.render()

    def move_layer_up(self):
        if self.active_index >= len(self.layers) - 1:
            return
        self.push_history()
        self.layers[self.active_index], self.layers[self.active_index + 1] = \
            self.layers[self.active_index + 1], self.layers[self.active_index]
        self.active_index += 1
        self.render_layer_list()
        self.render()

    def move_layer_down(self):
        if self.active_index <= 0:
            return
        self.push_history()
        self.layers[self.active_index], self.layers[self.active_index - 1] = \
            self.layers[self.active_index - 1], self.layers[self.active_index]
        self.active_index -= 1
        self.render_layer_list()
        self.render()

    def clear_active_layer(self):
        self.push_history()
        layer = self.layers[self.active_index]
        layer.image = Image.new("RGBA", (self.canvas_w, self.canvas_h), (0, 0, 0, 0))
        self.render()
        self.notepad.mark_unsaved()

    # ---------------- 캔버스 ----------------
    def open_new_canvas_dialog(self):
        win = tk.Toplevel(self)
        win.title("New canvas")
        win.configure(bg=GRAY)
        win.transient(self)
        win.grab_set()
        tk.Label(win, text="Width (px):", bg=GRAY).pack(anchor="w", padx=10, pady=(10, 2))
        w_var = tk.IntVar(value=self.canvas_w)
        tk.Entry(win, textvariable=w_var).pack(padx=10, fill="x")
        tk.Label(win, text="Height (px):", bg=GRAY).pack(anchor="w", padx=10, pady=(8, 2))
        h_var = tk.IntVar(value=self.canvas_h)
        tk.Entry(win, textvariable=h_var).pack(padx=10, fill="x")

        def apply():
            w = clamp(w_var.get(), 16, 4000)
            h = clamp(h_var.get(), 16, 4000)
            win.destroy()
            if self.layers:
                self.push_history()
            self.reset_canvas(w, h)

        btns = tk.Frame(win, bg=GRAY)
        btns.pack(pady=10)
        tk.Button(btns, text="Create", command=apply).pack(side="left", padx=6)
        tk.Button(btns, text="Cancel", command=win.destroy).pack(side="left", padx=6)

    def reset_canvas(self, w, h):
        self.canvas_w, self.canvas_h = w, h
        self.layers = [Layer("Layer 1", w, h)]
        self.active_index = 0
        self.selection = None
        self.render_layer_list()
        self._fit_zoom_to_view()
        self.render()

    def _composite_transparent(self):
        """레이어들만 투명 배경 위에 합성 (문서에 삽입 / 스포이드용 -- 원본처럼 투명 유지)."""
        result = Image.new("RGBA", (self.canvas_w, self.canvas_h), (0, 0, 0, 0))
        for layer in self.layers:
            if layer.visible:
                result = Image.alpha_composite(result, layer.image)
        if self.selection is not None:
            crop = self.selection["crop"]
            result.paste(crop, (int(round(self.selection["x"])), int(round(self.selection["y"]))), crop)
        return result

    def _composite(self):
        """흰 배경 위에 합성 (화면 미리보기 전용 -- 원본 CSS의 흰 캔버스 배경과 동일한 용도)."""
        white_bg = Image.new("RGBA", (self.canvas_w, self.canvas_h), (255, 255, 255, 255))
        return Image.alpha_composite(white_bg, self._composite_transparent())

    def render(self, preview_lasso=False):
        composite = self._composite()
        if self.zoom != 1.0:
            disp = composite.resize((max(1, int(self.canvas_w * self.zoom)), max(1, int(self.canvas_h * self.zoom))),
                                     Image.NEAREST)
        else:
            disp = composite
        self.photo_ref = ImageTk.PhotoImage(disp)
        self.canvas.itemconfig(self.canvas_image_id, image=self.photo_ref)
        self.canvas.config(scrollregion=(0, 0, disp.width, disp.height))
        if preview_lasso and len(self.lasso_points) >= 2:
            pts = [(px * self.zoom, py * self.zoom) for px, py in self.lasso_points]
            self.canvas.delete("lasso_preview")
            flat = [c for p in pts for c in p]
            self.canvas.create_line(*flat, fill="#000080", dash=(4, 2), tags="lasso_preview")
        else:
            self.canvas.delete("lasso_preview")

    def zoom_in(self):
        self.zoom = clamp(self.zoom * 1.25, 0.1, 8)
        self.render()

    def zoom_out(self):
        self.zoom = clamp(self.zoom / 1.25, 0.1, 8)
        self.render()

    def zoom_reset(self):
        self.zoom = 1.0
        self.render()

    def _fit_zoom_to_view(self):
        self.update_idletasks()
        avail_w = max(50, self.canvas.winfo_width() - 24)
        avail_h = max(50, self.canvas.winfo_height() - 24)
        fit = min(avail_w / self.canvas_w, avail_h / self.canvas_h, 1.0)
        self.zoom = max(0.1, fit)
        self.render()

    def toggle_fullscreen(self):
        self._is_fullscreen = not self._is_fullscreen
        self.attributes("-fullscreen", self._is_fullscreen)
        self.fs_btn.config(text="Exit fullscreen" if self._is_fullscreen else "Fullscreen")

    def insert_into_document(self):
        # 원본과 동일하게 투명 배경을 유지한 채로 문서에 삽입 (흰 배경 안 깔림)
        if self.selection is not None:
            self._commit_selection()
        result = self._composite_transparent()
        self.notepad.insert_finished_painting(result)
        self.close()

    def close(self):
        self.destroy()

    def on_key(self, event):
        if self._shortcuts_suspended:
            return
        typing_widget = str(self.focus_get().__class__.__name__) if self.focus_get() else ""
        if typing_widget in ("Entry", "Spinbox"):
            return
        key = event.keysym.lower()
        ctrl = bool(event.state & 0x4)
        if ctrl:
            if key == "z":
                self.undo()
            elif key == "y":
                self.redo()
            elif key == "d":
                self.duplicate_layer()
            elif key == "n":
                self.open_new_canvas_dialog()
            elif key == "e":
                self.merge_down()
            elif key == "0":
                self.zoom_reset()
            return
        if key == "escape":
            # 전체화면 상태면 Esc는 전체화면만 빠져나오고, Paint 자체를 닫진 않음
            if self._is_fullscreen:
                self.toggle_fullscreen()
            else:
                self.close()
        elif key in ("delete", "backspace") and self.selection:
            self.selection = None
            self.render()
        elif key == "b":
            self.set_tool("brush")
        elif key == "e":
            self.set_tool("eraser")
        elif key == "p":
            self.set_tool("eyedropper")
        elif key == "m":
            self.set_tool("lasso")
        elif key == "g":
            self.set_tool("lasso-fill")
        elif key == "d":
            self.set_tool("lasso-erase")
        elif key in ("plus", "equal"):
            self.zoom_in()
        elif key in ("minus", "underscore"):
            self.zoom_out()


# ----------------------------------------------------------------------------
def main():
    root = tk.Tk()
    NotepadApp(root)
    root.mainloop()


if __name__ == "__main__":
    main()
