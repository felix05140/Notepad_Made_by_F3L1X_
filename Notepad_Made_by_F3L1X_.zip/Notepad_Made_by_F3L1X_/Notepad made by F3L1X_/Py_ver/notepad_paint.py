#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Notepad + Paint (Python / Tkinter + Pillow port)
=================================================

원본은 브라우저에서 돌아가는 단일 HTML 파일(Windows98/XP 스타일 메모장 + 그림판)
이었습니다. 이 파일은 그 앱의 기능을 최대한 비슷하게 데스크탑 파이썬 앱으로
옮긴 것입니다.

필요한 패키지:
    pip install Pillow

실행:
    python notepad_paint.py

참고: 기본 폰트는 'Noto Serif KR'로 설정되어 있습니다. 원본은 이 폰트를 구글 폰트
웹폰트로 자동 불러왔지만, 데스크탑 tkinter는 OS에 실제로 설치된 폰트만 쓸 수 있습니다.
'Noto Serif KR'이 시스템에 설치되어 있지 않으면 tkinter가 조용히 기본 폰트로 대체해서
보여줍니다 (에러는 안 남). 정확히 똑같이 보이게 하려면 Noto Serif KR 폰트를 OS에 설치해
주세요.

원본과 다른 점 (브라우저 전용 기능이라 데스크탑에는 그대로 옮길 수 없는 부분):
  - localStorage 자동저장  -> 스크립트와 같은 폴더의 .notepad_autosave.json 파일로 대체
  - <input type=file> / Blob 다운로드 -> 표준 파일 열기/저장 대화상자로 대체
  - 이미지 드래그(고스트 이미지 따라다니는 것) -> 클릭으로 선택 후 위/아래/좌우
    화살표 또는 드래그로 이동하는 방식으로 단순화
  - CSS 그라데이션 타이틀바 등 일부 장식은 tkinter 한계로 단색으로 근사
"""

import base64
import copy
import io
import json
import os
import random
import re
from html.parser import HTMLParser

import tkinter as tk
from tkinter import ttk, filedialog, messagebox, simpledialog

import webbrowser

try:
    from PIL import Image, ImageDraw, ImageTk, ImageChops
except ImportError:  # pragma: no cover
    raise SystemExit(
        "Pillow가 필요합니다. 먼저 'pip install Pillow' 를 실행한 뒤 다시 실행해주세요."
    )

# ----------------------------------------------------------------------------
# 공통 색상 / 상수 (원본 CSS 변수와 최대한 맞춤)
# ----------------------------------------------------------------------------
GRAY = "#C0C0C0"
DARK_GRAY = "#808080"
BORDER_NAVY = "#000080"
TITLEBAR_BLUE = "#000080"

AVAILABLE_FONTS = [
    "Noto Serif KR", "Nanum Myeongjo", "Malgun Gothic", "Times New Roman",
    "Georgia", "Cambria", "Arial", "Courier New", "Comic Sans MS",
    "Verdana", "Tahoma", "Impact",
]
DEFAULT_FONT_FAMILY = "Noto Serif KR"

# "Others" 버튼 -> Language 메뉴용 번역 테이블. 메뉴/툴바처럼 '구조적인' 라벨만
# 번역하고, 장난스러운 영어 알림 문구들("Ye"/"Nuh uh" 같은 것)은 원본 톤을
# 살리려고 그대로 둠 (이 부분은 번역 대상에서 제외).
TRANSLATIONS = {
    "en": {
        "menu_file": "File(F)", "menu_edit": "Edit(E)", "menu_insert": "Insert(I)",
        "menu_format": "Format(O)", "menu_others": "Others",
        "file_new": "New file      Ctrl+N", "file_open": "Open          Ctrl+O",
        "file_save": "Save          Ctrl+S", "file_saveas": "Save as...    Ctrl+Shift+S",
        "edit_undo": "Undo          Ctrl+Z", "edit_redo": "Redo          Ctrl+Y",
        "edit_selectall": "Select all    Ctrl+A",
        "insert_image": "Insert image", "insert_resize": "Resize image",
        "insert_paint": "Open Paint...",
        "format_font": "Change font", "format_size": "Change font size",
        "format_bold": "Bold          Ctrl+B", "format_italic": "Italic        Ctrl+Shift+I",
        "format_underline": "Underline     Ctrl+U", "format_strike": "Strike        Ctrl+Shift+X",
        "format_bg": "Change bg color", "format_fg": "Change text color",
        "format_border": "Change border color", "format_dark": "Turn on / off dark mode",
        "tb_new": "New file", "tb_open": "Open", "tb_save": "Save",
        "tb_insert": "Insert image", "tb_paint": "Paint", "tb_dark": "Dark mode",
        "tb_fullscreen": "Fullscreen", "tb_exit_fullscreen": "Exit fullscreen",
        "tb_others": "Others",
        "others_language": "Language",
        "others_advanced": "Advanced",
        "adv_underline_color": "Underline color...",
        "adv_strike_color": "Strikethrough color...",
        "adv_highlight": "Highlight...",
        "adv_clear_highlight": "Clear highlight",
        "adv_clear_format": "Clear all formatting",
        "others_facts": "Facts about F3L1X_",
        "others_about": "About",
        "about_text": "Notepad + Paint (Python port)\nOriginal: F3L1X_\nPorted to Tkinter/Pillow.",
        "status_fmt": "Chars: {chars} | Words: {words} | Ln {line}, Col {col}",
        "title_suffix": " - Notepad",

        "trash_title": "Hold up!", "trash_msg": "Do u rlly want 2 trash ur unsaved text??",
        "trash_yes": "Ye", "trash_no": "Nuh uh",
        "alert_select_text_first": "Select text first bruh",
        "alert_click_image_first": "Click da image first bruh",
        "alert_select_text_color_first": "Select text 2 color first bruh",
        "alert_numbers_only": "Numbers only lol",
        "alert_image_open_fail": "Can't open that image: {err}",
        "alert_error_title": "Error",
        "alert_saved_title": "Saved",
        "alert_saved_plain": "File saved lol",
        "alert_saved_with_image_note": "File saved lol (but it's txt so images/formatting didn't get saved)",
        "alert_saved_markdown_note": "File saved as Markdown (formatting and images are kept)",
        "dlg_resize_title": "Resize image", "dlg_resize_width": "Width(px):",
        "dlg_resize_height": "Height(px):", "dlg_resize_keepratio": "Keep aspect ratio",
        "dlg_apply": "Apply", "dlg_cancel": "Cancel", "dlg_ok": "Ok",
        "dlg_font_title": "Change font",
        "dlg_fontsize_title": "Set text size",
        "dlg_fontsize_desc": "Applies to the selected text, or the whole document if nothing's selected.",
        "dlg_fontsize_label": "Text size(px):",
        "saveas_title": "Save as", "saveas_prompt": "Name da file bru (Ex: Memo.txt)",
        "colorpicker_title": "Pick a color",
        "autosave_title": "Unsaved work found",
        "autosave_msg": "Found something you were working on before. Restore it?",
        "autosave_restore": "Restore", "autosave_discard": "Discard",
        "quit_title": "Quit", "quit_msg": "You have unsaved changes. Quit anyway?",
        "quit_yes": "Quit", "quit_no": "Cancel",
        "notice_title": "Notice",

        "paint_undo": "↶ Undo", "paint_redo": "↷ Redo",
        "paint_tool_brush": "Brush (B)", "paint_tool_eraser": "Eraser (E)",
        "paint_tool_eyedropper": "Eyedropper (P)", "paint_tool_lasso": "Lasso Move (M)",
        "paint_tool_lassofill": "Lasso Fill (G)", "paint_tool_lassoerase": "Lasso Erase (D)",
        "paint_size": "Size:", "paint_color": "Color:", "paint_opacity": "Opacity%:",
        "paint_clearlayer": "Clear layer", "paint_newcanvas_btn": "New canvas",
        "paint_zoomout": "Zoom -", "paint_zoomreset": "Reset", "paint_zoomin": "Zoom +",
        "paint_insert": "Insert into document",
        "paint_save_png": "Save (PNG)",
        "paint_save_png_title": "Enter file name to save",
        "paint_save_png_success": "Image saved",
        "paint_save_bg_title": "Save as image",
        "paint_save_bg_msg": "Save with a white background, or keep the background transparent?",
        "paint_save_with_bg": "Save with background", "paint_save_without_bg": "Save without background",
        "paint_unsaved_title": "Unsaved drawing",
        "paint_unsaved_msg": "Your drawing hasn't been saved. Close anyway and lose it?",
        "paint_unsaved_close": "Close without saving", "paint_unsaved_cancel": "Cancel",
        "paint_layers_header": "Layers", "paint_add": "Add", "paint_dup": "Dup", "paint_del": "Del",
        "paint_merge": "Merge↓",
        "paint_newcanvas_dialog_title": "New canvas",
        "paint_width_label": "Width (px):", "paint_height_label": "Height (px):",
        "paint_create": "Create",
        "paint_layer_default_name": "Layer {n}", "paint_layer_copy_suffix": " copy",

        "filetype_text_html": "Text/Markdown/HTML", "filetype_all": "All files",
        "filetype_text": "Text file", "filetype_markdown": "Markdown file", "filetype_images": "Images",
        "dlg_open_title": "Open", "dlg_saveas_title": "Save as",
        "dlg_insertimage_title": "Insert image",
    },
    "ko": {
        "menu_file": "파일(F)", "menu_edit": "편집(E)", "menu_insert": "삽입(I)",
        "menu_format": "서식(O)", "menu_others": "기타",
        "file_new": "새 파일      Ctrl+N", "file_open": "열기          Ctrl+O",
        "file_save": "저장          Ctrl+S", "file_saveas": "다른 이름으로 저장  Ctrl+Shift+S",
        "edit_undo": "실행 취소     Ctrl+Z", "edit_redo": "다시 실행     Ctrl+Y",
        "edit_selectall": "전체 선택     Ctrl+A",
        "insert_image": "이미지 삽입", "insert_resize": "이미지 크기 조절",
        "insert_paint": "그림판 열기...",
        "format_font": "글꼴 변경", "format_size": "글자 크기 변경",
        "format_bold": "굵게          Ctrl+B", "format_italic": "기울임        Ctrl+Shift+I",
        "format_underline": "밑줄          Ctrl+U", "format_strike": "취소선        Ctrl+Shift+X",
        "format_bg": "배경색 변경", "format_fg": "글자색 변경",
        "format_border": "테두리색 변경", "format_dark": "다크 모드 켜기/끄기",
        "tb_new": "새 파일", "tb_open": "열기", "tb_save": "저장",
        "tb_insert": "이미지 삽입", "tb_paint": "그림판", "tb_dark": "다크 모드",
        "tb_fullscreen": "전체화면", "tb_exit_fullscreen": "전체화면 종료",
        "tb_others": "기타",
        "others_language": "언어",
        "others_advanced": "고급",
        "adv_underline_color": "밑줄 색상...",
        "adv_strike_color": "취소선 색상...",
        "adv_highlight": "형광펜...",
        "adv_clear_highlight": "형광펜 지우기",
        "adv_clear_format": "서식 전부 지우기",
        "others_facts": "F3L1X_에 대한 사실들",
        "others_about": "정보",
        "about_text": "메모장 + 그림판 (파이썬 포팅판)\n원작: F3L1X_\nTkinter/Pillow로 포팅했어요.",
        "status_fmt": "글자 수: {chars} | 단어 수: {words} | {line}줄 {col}칸",
        "title_suffix": " - 메모장",

        "trash_title": "잠깐만요!", "trash_msg": "저장 안 한 내용이 있는데, 정말 버리시겠어요?",
        "trash_yes": "네, 버릴게요", "trash_no": "아니요, 저장할게요",
        "alert_select_text_first": "먼저 텍스트를 선택해 주세요",
        "alert_click_image_first": "먼저 이미지를 클릭해 주세요",
        "alert_select_text_color_first": "색을 바꾸려면 먼저 텍스트를 선택해 주세요",
        "alert_numbers_only": "숫자만 입력해 주세요",
        "alert_image_open_fail": "이미지를 열 수 없어요: {err}",
        "alert_error_title": "오류",
        "alert_saved_title": "저장 완료",
        "alert_saved_plain": "파일을 저장했어요",
        "alert_saved_with_image_note": "파일을 저장했어요 (단, txt 파일이라 이미지와 서식은 저장되지 않았어요)",
        "alert_saved_markdown_note": "마크다운 파일로 저장했어요 (서식이랑 이미지도 같이 저장됌)",
        "dlg_resize_title": "이미지 크기 조절", "dlg_resize_width": "가로(px):",
        "dlg_resize_height": "세로(px):", "dlg_resize_keepratio": "가로세로 비율 유지",
        "dlg_apply": "적용", "dlg_cancel": "취소", "dlg_ok": "확인",
        "dlg_font_title": "글꼴 변경",
        "dlg_fontsize_title": "글자 크기 설정",
        "dlg_fontsize_desc": "선택한 텍스트에 적용돼요. 선택한 게 없으면 문서 전체에 적용돼요.",
        "dlg_fontsize_label": "글자 크기(px):",
        "saveas_title": "다른 이름으로 저장", "saveas_prompt": "파일 이름을 입력해 주세요 (예: Memo.txt)",
        "colorpicker_title": "색상 선택",
        "autosave_title": "저장하지 않은 작업을 발견했어요",
        "autosave_msg": "이전에 작업하시던 내용이 있어요. 복원하시겠어요?",
        "autosave_restore": "복원", "autosave_discard": "버리기",
        "quit_title": "종료", "quit_msg": "저장하지 않은 변경 사항이 있어요. 그래도 종료하시겠어요?",
        "quit_yes": "종료", "quit_no": "취소",
        "notice_title": "알림",

        "paint_undo": "↶ 실행 취소", "paint_redo": "↷ 다시 실행",
        "paint_tool_brush": "브러시 (B)", "paint_tool_eraser": "지우개 (E)",
        "paint_tool_eyedropper": "스포이드 (P)", "paint_tool_lasso": "올가미 이동 (M)",
        "paint_tool_lassofill": "올가미 채우기 (G)", "paint_tool_lassoerase": "올가미 지우기 (D)",
        "paint_size": "크기:", "paint_color": "색상:", "paint_opacity": "불투명도%:",
        "paint_clearlayer": "레이어 지우기", "paint_newcanvas_btn": "새 캔버스",
        "paint_zoomout": "축소", "paint_zoomreset": "원래대로", "paint_zoomin": "확대",
        "paint_insert": "문서에 삽입",
        "paint_save_png": "PNG로 저장",
        "paint_save_png_title": "저장할 파일 이름을 입력하세요",
        "paint_save_png_success": "이미지를 저장했어요",
        "paint_save_bg_title": "이미지로 저장",
        "paint_save_bg_msg": "배경을 흰색으로 채워서 저장할까요, 아니면 배경 없이(투명하게) 저장할까요?",
        "paint_save_with_bg": "배경 포함해서 저장", "paint_save_without_bg": "배경 없이 저장",
        "paint_unsaved_title": "저장 안 된 그림",
        "paint_unsaved_msg": "그림을 저장 안 했어요. 그냥 닫으면 지금까지 그린 거 다 날아가는데 닫을까요?",
        "paint_unsaved_close": "저장 안 하고 닫기", "paint_unsaved_cancel": "취소",
        "paint_layers_header": "레이어", "paint_add": "추가", "paint_dup": "복제", "paint_del": "삭제",
        "paint_merge": "병합↓",
        "paint_newcanvas_dialog_title": "새 캔버스",
        "paint_width_label": "가로 (px):", "paint_height_label": "세로 (px):",
        "paint_create": "만들기",
        "paint_layer_default_name": "레이어 {n}", "paint_layer_copy_suffix": " 사본",

        "filetype_text_html": "텍스트/마크다운/HTML", "filetype_all": "모든 파일",
        "filetype_text": "텍스트 파일", "filetype_markdown": "마크다운 파일", "filetype_images": "이미지",
        "dlg_open_title": "열기", "dlg_saveas_title": "다른 이름으로 저장",
        "dlg_insertimage_title": "이미지 삽입",
    },
    "ja": {
        "menu_file": "ファイル(F)", "menu_edit": "編集(E)", "menu_insert": "挿入(I)",
        "menu_format": "書式(O)", "menu_others": "その他",
        "file_new": "新規作成      Ctrl+N", "file_open": "開く          Ctrl+O",
        "file_save": "保存          Ctrl+S", "file_saveas": "名前を付けて保存  Ctrl+Shift+S",
        "edit_undo": "元に戻す      Ctrl+Z", "edit_redo": "やり直し      Ctrl+Y",
        "edit_selectall": "すべて選択    Ctrl+A",
        "insert_image": "画像を挿入", "insert_resize": "画像サイズ変更",
        "insert_paint": "ペイントを開く...",
        "format_font": "フォント変更", "format_size": "文字サイズ変更",
        "format_bold": "太字          Ctrl+B", "format_italic": "斜体          Ctrl+Shift+I",
        "format_underline": "下線          Ctrl+U", "format_strike": "取り消し線    Ctrl+Shift+X",
        "format_bg": "背景色を変更", "format_fg": "文字色を変更",
        "format_border": "枠線の色を変更", "format_dark": "ダークモード切替",
        "tb_new": "新規作成", "tb_open": "開く", "tb_save": "保存",
        "tb_insert": "画像を挿入", "tb_paint": "ペイント", "tb_dark": "ダークモード",
        "tb_fullscreen": "全画面表示", "tb_exit_fullscreen": "全画面表示を終了",
        "tb_others": "その他",
        "others_language": "言語",
        "others_advanced": "詳細設定",
        "adv_underline_color": "下線の色...",
        "adv_strike_color": "取り消し線の色...",
        "adv_highlight": "蛍光マーカー...",
        "adv_clear_highlight": "蛍光マーカーを消す",
        "adv_clear_format": "書式をすべて消す",
        "others_facts": "F3L1X_についての事実",
        "others_about": "このアプリについて",
        "about_text": "メモ帳 + ペイント (Python移植版)\n原作: F3L1X_\nTkinterとPillowを使って移植しました。",
        "status_fmt": "文字数: {chars} | 単語数: {words} | {line}行 {col}列",
        "title_suffix": " - メモ帳",

        "trash_title": "ちょっと待ってください",
        "trash_msg": "保存されていない内容があります。本当に破棄しますか?",
        "trash_yes": "はい、破棄します", "trash_no": "いいえ、保存します",
        "alert_select_text_first": "先にテキストを選択してください",
        "alert_click_image_first": "先に画像をクリックしてください",
        "alert_select_text_color_first": "色を変更する前にテキストを選択してください",
        "alert_numbers_only": "数字のみ入力してください",
        "alert_image_open_fail": "この画像を開けませんでした: {err}",
        "alert_error_title": "エラー",
        "alert_saved_title": "保存しました",
        "alert_saved_plain": "ファイルを保存しました",
        "alert_saved_with_image_note": "ファイルを保存しました(ただしtxt形式のため、画像や書式は保存されていません)",
        "alert_saved_markdown_note": "Markdownファイルとして保存しました(書式と画像もそのまま保存されます)",
        "dlg_resize_title": "画像サイズの変更", "dlg_resize_width": "幅(px):",
        "dlg_resize_height": "高さ(px):", "dlg_resize_keepratio": "縦横比を保持する",
        "dlg_apply": "適用", "dlg_cancel": "キャンセル", "dlg_ok": "OK",
        "dlg_font_title": "フォントの変更",
        "dlg_fontsize_title": "文字サイズの設定",
        "dlg_fontsize_desc": "選択したテキストに適用されます。何も選択していない場合は、文書全体に適用されます。",
        "dlg_fontsize_label": "文字サイズ(px):",
        "saveas_title": "名前を付けて保存", "saveas_prompt": "ファイル名を入力してください(例: Memo.txt)",
        "colorpicker_title": "色を選択",
        "autosave_title": "保存されていない作業が見つかりました",
        "autosave_msg": "以前作業していた内容が見つかりました。復元しますか?",
        "autosave_restore": "復元する", "autosave_discard": "破棄する",
        "quit_title": "終了", "quit_msg": "保存されていない変更があります。このまま終了しますか?",
        "quit_yes": "終了する", "quit_no": "キャンセル",
        "notice_title": "お知らせ",

        "paint_undo": "↶ 元に戻す", "paint_redo": "↷ やり直し",
        "paint_tool_brush": "ブラシ (B)", "paint_tool_eraser": "消しゴム (E)",
        "paint_tool_eyedropper": "スポイト (P)", "paint_tool_lasso": "なげなわ移動 (M)",
        "paint_tool_lassofill": "なげなわ塗りつぶし (G)", "paint_tool_lassoerase": "なげなわ消去 (D)",
        "paint_size": "サイズ:", "paint_color": "色:", "paint_opacity": "不透明度%:",
        "paint_clearlayer": "レイヤーを消去", "paint_newcanvas_btn": "新規キャンバス",
        "paint_zoomout": "縮小", "paint_zoomreset": "リセット", "paint_zoomin": "拡大",
        "paint_insert": "文書に挿入",
        "paint_save_png": "PNGで保存",
        "paint_save_png_title": "保存するファイル名を入力してください",
        "paint_save_png_success": "画像を保存しました",
        "paint_save_bg_title": "画像として保存",
        "paint_save_bg_msg": "背景を白で塗りつぶして保存しますか、それとも背景を透明のまま保存しますか?",
        "paint_save_with_bg": "背景ありで保存", "paint_save_without_bg": "背景なしで保存",
        "paint_unsaved_title": "保存されていない絵",
        "paint_unsaved_msg": "絵がまだ保存されていません。このまま閉じると、描いた内容が全部消えますが閉じますか?",
        "paint_unsaved_close": "保存せずに閉じる", "paint_unsaved_cancel": "キャンセル",
        "paint_layers_header": "レイヤー", "paint_add": "追加", "paint_dup": "複製", "paint_del": "削除",
        "paint_merge": "統合↓",
        "paint_newcanvas_dialog_title": "新規キャンバス",
        "paint_width_label": "幅 (px):", "paint_height_label": "高さ (px):",
        "paint_create": "作成",
        "paint_layer_default_name": "レイヤー {n}", "paint_layer_copy_suffix": " のコピー",

        "filetype_text_html": "テキスト/Markdown/HTML", "filetype_all": "すべてのファイル",
        "filetype_text": "テキストファイル", "filetype_markdown": "Markdownファイル", "filetype_images": "画像",
        "dlg_open_title": "開く", "dlg_saveas_title": "名前を付けて保存",
        "dlg_insertimage_title": "画像を挿入",
    },
}

# 언어 이름은 지금 UI 언어가 뭐든 상관없이 항상 그 언어 고유 표기로 보여줌
# (영어 목록에서도 "한국어"/"日本語"로 보이고, 한국어 목록에서도 동일)
LANGUAGE_NAMES = {"en": "English (default)", "ko": "한국어", "ja": "日本語"}

# "Others" 메뉴 -> "Facts about F3L1X_" 눌렀을 때 랜덤으로 보여줄 목록.
# 원하는 내용으로 자유롭게 채워 넣으면 됨 (문자열 하나당 사실 하나).
# 언어별 "Facts about F3L1X_" 목록. 아직 번역이 없는 언어(예: 한국어)는
# get_facts()가 자동으로 영어("en") 목록으로 대체해서 보여줌.
FACTS_BY_LANG = {
    "en": [
        "F3L1X_ is 16 yrs old, Korean, male",
        "F3L1X_ prefers to use \"He / They\" pronouns",
        "F3L1X_ is fking terrible at foreign languages \U0001F480\U0001F480",
        "F3L1X_ sucks at coding, so he uses Claude to code lol",
        "F3L1X_ is gay, no cap.",
        "F3L1X_ is just a b1tch and swears a lot",
        "F3L1X_ is emotionally fragile and gets hurt easily\n↳ That's why he always turns off the comments lmao",
        "F3L1X_ has a bit of self-hatred issue",
        "F3L1X_ rlly likes to play alone",
        "F3L1X_ is lazy as f*ck!!!!",
        "F3L1X_ has a Zeta account, but he makes characters solely for his own fun (selfish, lol)\n"
        "↳ F3L1X_'s Zeta account is \"F3L1X_ (@N0th1ng.)\"",
    ],
    "ja": [
        "F3L1X_は16歳、韓国人の男性",
        "F3L1X_は「彼 / 彼ら」の代名詞の使用を好む",
        "F3L1X_は外国語がクソ下手 \U0001F480\U0001F480",
        "F3L1X_はコーディングがクソ雑魚なので、Claudeを使ってコードを書いてる www",
        "F3L1X_はゲイ、ガチで。",
        "F3L1X_はただのクソ野郎で、めちゃくちゃ口が悪い",
        "F3L1X_はメンタルが豆腐なので傷つきやすい\n↳ だからいつもコメント欄をオフにしている wwwww",
        "F3L1X_は少し自己嫌悪の問題がある",
        "F3L1X_はマジで一人で遊ぶのが好き",
        "F3L1X_はクソほど怠惰!!!!",
        "F3L1X_はZetaのアカウントを持っているが、純粋に自分の楽しみのためだけにキャラクターを作っている（超利己的で草）\n"
        "↳ F3L1X_のZetaアカウントは「F3L1X_ (@N0th1ng.)」",
    ],
    "ko": [
        "F3L1X_는 16살이고 한국인임, 남성임",
        "F3L1X_는 \"그 / 그들\" 대명사 사용을 선호함",
        "F3L1X_는 외국어 존나 못함 \U0001F480\U0001F480",
        "F3L1X_는 코딩 개못해서 코딩할 때 클로드 씀 ㅋㅋ",
        "F3L1X_는 게이임, 구라 아니고 찐임 ㅋ",
        "F3L1X_는 걍 미친놈(?)이고 욕을 존나 많이 함",
        "F3L1X_는 유리멘탈이라 상처를 종나 잘 받음\n↳ 그래서 항상 댓글 창을 꺼둠 ㅋㅋ",
        "F3L1X_는 자기혐오 문제가 약간 있음",
        "F3L1X_는 혼자 노는 걸 존나게 좋아함",
        "F3L1X_는 존나게 게을러 터진 놈임!!!!",
        "F3L1X_는 제타 계정이 있지만 오직 자기 재미만을 위해 캐릭터를 만듦 (이기적인 새키 ㅋㅋ)\n"
        "↳ F3L1X_의 제타 계정은 \"F3L1X_ (@N0th1ng.)\"임",
    ],
}

AUTOSAVE_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), ".notepad_autosave.json")
# 언어 같은 가벼운 환경설정을 저장하는 파일 (자동저장 파일과는 별개 -- 문서 내용이 없어도
# 항상 바로 기록/로드됨, 그래서 앱을 완전히 다시 켜도 마지막으로 고른 언어가 유지됨)
SETTINGS_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), ".notepad_settings.json")


def load_settings():
    try:
        with open(SETTINGS_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}


def save_settings(data):
    try:
        with open(SETTINGS_FILE, "w", encoding="utf-8") as f:
            json.dump(data, f)
    except Exception:
        pass

# 타이핑 중 URL처럼 생긴 단어를 자동으로 링크로 바꿔주는 정규식 (원본과 동일한 로직)
URL_REGEX = re.compile(
    r"(?:https?://)?(?:www\.)?[a-zA-Z0-9][a-zA-Z0-9-]*(?:\.[a-zA-Z0-9-]+)*\."
    r"(?:com|net|org|io|co|kr|dev|app|edu|gov|info|xyz|me|us|uk|jp|cn)(?:/\S*)?",
    re.IGNORECASE,
)


def clamp(v, lo, hi):
    return max(lo, min(hi, v))


# ----------------------------------------------------------------------------
# 아주 작은 HTML 파서 (원본이 innerHTML 을 그대로 저장/복원하던 방식을 최대한 흉내)
# b/strong, i/em, u, s/strike, font(size/color), img(src=data uri) 정도만 지원
# ----------------------------------------------------------------------------
class _SimpleHTMLImporter(HTMLParser):
    def __init__(self, editor):
        super().__init__(convert_charrefs=True)
        self.editor = editor
        self.stack = []  # list of dict: {'bold':..,'italic':..,'underline':..,'strike':..,'color':..,'size':..}
        self.cur = {"bold": False, "italic": False, "underline": False, "strike": False, "color": None, "size": None}

    def _push(self, **kw):
        self.stack.append(dict(self.cur))
        self.cur.update(kw)

    def _pop(self):
        if self.stack:
            self.cur = self.stack.pop()

    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        tag = tag.lower()
        if tag in ("b", "strong"):
            self._push(bold=True)
        elif tag in ("i", "em"):
            self._push(italic=True)
        elif tag == "u":
            self._push(underline=True)
        elif tag in ("s", "strike", "del"):
            self._push(strike=True)
        elif tag == "font":
            kw = {}
            if attrs.get("color"):
                kw["color"] = attrs["color"]
            self._push(**kw)
        elif tag == "span":
            style = attrs.get("style", "")
            kw = {}
            m = re.search(r"font-size\s*:\s*(\d+)px", style)
            if m:
                kw["size"] = int(m.group(1))
            m = re.search(r"color\s*:\s*(#[0-9a-fA-F]{3,6})", style)
            if m:
                kw["color"] = m.group(1)
            self._push(**kw)
        elif tag == "br":
            self.editor.insert_plain_text("\n", dict(self.cur))
        elif tag == "img":
            src = attrs.get("src", "")
            self.editor.insert_image_from_src(src)

    def handle_endtag(self, tag):
        tag = tag.lower()
        if tag in ("b", "strong", "i", "em", "u", "s", "strike", "del", "font", "span"):
            self._pop()
        if tag == "p" or tag == "div":
            self.editor.insert_plain_text("\n", dict(self.cur))

    def handle_data(self, data):
        if data:
            self.editor.insert_plain_text(data, dict(self.cur))


# ----------------------------------------------------------------------------
# 메모장 (Notepad)
# ----------------------------------------------------------------------------
class NotepadApp:
    def __init__(self, root):
        self.root = root
        self.current_file_name = None
        self.current_file_path = None
        self.unsaved = False
        # 마지막으로 골랐던 언어를 설정 파일에서 불러옴 (없거나 깨졌으면 영어로 시작)
        saved_settings = load_settings()
        saved_lang = saved_settings.get("lang")
        self.lang = saved_lang if saved_lang in TRANSLATIONS else "en"
        self.font_family = DEFAULT_FONT_FAMILY
        self.font_size_px = 16
        self.border_color = BORDER_NAVY
        self.dark_mode = False
        self.images = {}          # image_id -> {'pil': Image, 'photo': ImageTk.PhotoImage, 'tag': str}
        self.selected_image_id = None
        self.paint_window = None
        self._img_counter = 0
        self._link_counter = 0
        self._autosave_job = None
        self._is_fullscreen = False

        self._build_ui()
        self._bind_shortcuts()
        self.title_update()
        self.update_status()
        self.root.after(300, self._try_restore_autosave)

    # ---------------- 다국어 ----------------
    def tr(self, key):
        return TRANSLATIONS[self.lang].get(key, TRANSLATIONS["en"].get(key, key))

    def open_others_menu(self):
        t = self.tr
        menu = tk.Menu(self.root, tearoff=0)
        lang_menu = tk.Menu(menu, tearoff=0)
        lang_var = tk.StringVar(value=self.lang)
        for code in ("en", "ko", "ja"):
            lang_menu.add_radiobutton(label=LANGUAGE_NAMES[code], variable=lang_var, value=code,
                                       command=lambda c=code: self.apply_language(c))
        menu.add_cascade(label=t("others_language"), menu=lang_menu)

        adv_menu = tk.Menu(menu, tearoff=0)
        adv_menu.add_command(label=t("adv_underline_color"), command=self.set_underline_color)
        adv_menu.add_command(label=t("adv_strike_color"), command=self.set_strike_color)
        adv_menu.add_command(label=t("adv_highlight"), command=self.set_highlight_color)
        adv_menu.add_command(label=t("adv_clear_highlight"), command=self.clear_highlight)
        adv_menu.add_separator()
        adv_menu.add_command(label=t("adv_clear_format"), command=self.clear_formatting)
        menu.add_cascade(label=t("others_advanced"), menu=adv_menu)

        menu.add_separator()
        menu.add_command(label=t("others_facts"), command=self.show_random_fact)
        # 버튼 바로 밑에 붙여서 띄움
        x = self.others_btn.winfo_rootx()
        y = self.others_btn.winfo_rooty() + self.others_btn.winfo_height()
        try:
            menu.tk_popup(x, y)
        finally:
            menu.grab_release()

    def get_facts(self):
        """현재 UI 언어에 맞는 Facts 목록. 그 언어로 번역된 목록이 없으면 영어로 대체."""
        return FACTS_BY_LANG.get(self.lang) or FACTS_BY_LANG.get("en") or ["N"]

    def show_random_fact(self):
        """Facts 창: 랜덤으로 하나 보여주는 게 아니라, ◁ 1 ▷ 식으로 직접 넘겨보는 작은 창.
        텍스트 길이가 언어/항목마다 다 달라서(한국어·일본어·영어 글자 수 차이 포함),
        창 크기를 고정하지 않고 매번 내용에 맞춰 다시 계산해서 잘리지 않게 함."""
        facts = self.get_facts()
        win = tk.Toplevel(self.root)
        win.title(self.tr("others_facts"))
        win.configure(bg=GRAY)
        win.transient(self.root)
        win.resizable(False, False)

        idx = {"i": random.randrange(len(facts))}

        # 한 줄 폭은 고정하되(너무 넓어지면 읽기 불편하니까), 세로 높이는
        # 텍스트가 길어지는 만큼 창 자체가 늘어나게 함.
        WRAP_WIDTH = 280
        MIN_WIN_WIDTH = 320

        box = tk.Frame(win, bg="white", bd=2, relief="sunken")
        box.pack(padx=14, pady=(14, 8), fill="both", expand=True)
        text_label = tk.Label(box, text=facts[idx["i"]], bg="white", wraplength=WRAP_WIDTH,
                               justify="left", padx=12, pady=12, font=("Malgun Gothic", 10))
        text_label.pack(fill="both", expand=True)

        nav = tk.Frame(win, bg=GRAY)
        nav.pack(pady=(0, 14))
        counter_label = tk.Label(nav, text=str(idx["i"] + 1), bg=GRAY, width=4,
                                  font=("Malgun Gothic", 9))

        def resize_to_fit():
            # 창에 고정 geometry가 한번 박히면 라벨 텍스트만 바꿔선 창이 안 커지므로,
            # geometry를 비워서 tkinter가 지금 내용 기준으로 자연스러운 크기를
            # 다시 계산하게 만듦.
            win.geometry("")
            win.update_idletasks()
            w = max(MIN_WIN_WIDTH, win.winfo_reqwidth())
            h = win.winfo_reqheight()
            win.geometry(f"{w}x{h}")

        def refresh():
            text_label.config(text=facts[idx["i"]])
            counter_label.config(text=str(idx["i"] + 1))
            resize_to_fit()

        def go_prev():
            idx["i"] = (idx["i"] - 1) % len(facts)
            refresh()

        def go_next():
            idx["i"] = (idx["i"] + 1) % len(facts)
            refresh()

        tk.Button(nav, text="◁", command=go_prev, width=3).pack(side="left", padx=4)
        counter_label.pack(side="left", padx=4)
        tk.Button(nav, text="▷", command=go_next, width=3).pack(side="left", padx=4)

        resize_to_fit()

    def apply_language(self, lang):
        if lang not in TRANSLATIONS:
            return
        self.lang = lang
        # 다음에 앱을 다시 켜도 이 언어로 바로 시작하도록 기록
        save_settings({"lang": lang})
        t = self.tr
        # 메뉴바는 항목 하나하나를 entryconfig로 고쳐쓰지 않고 통째로 다시 만들어 교체함
        # (인덱스 기반 수정은 구분선 개수를 잘못 세면 엉뚱한 항목이 바뀌거나 조용히
        #  실패하기 쉬움 -- Format 메뉴만 안 바뀌던 문제가 바로 그 증상이었음)
        self._build_menu()
        # 툴바 버튼들
        for btn, key in self._i18n_buttons:
            try:
                btn.config(text=t(key))
            except tk.TclError:
                pass
        # 풀스크린 버튼은 현재 상태에 따라 라벨이 다르므로 별도 갱신
        self.fullscreen_btn.config(text=t("tb_exit_fullscreen" if self._is_fullscreen else "tb_fullscreen"))
        self.title_update()
        self.update_status()
        self.root.update_idletasks()
        # 그림판 창이 열려있으면 그쪽 고정 UI도 같이 갱신
        if self.paint_window is not None and self.paint_window.winfo_exists():
            self.paint_window.retranslate()

    # ---------------- UI 구성 ----------------
    def _build_menu(self):
        """메뉴바를 (다시) 만듦. entryconfig로 라벨 하나하나 다시 쓰는 대신, 언어가
        바뀔 때마다 메뉴 전체를 새로 만들어 통째로 교체함 -- 인덱스 번호로 항목을
        찾아 바꾸는 방식은 구분선 개수를 하나라도 잘못 세면 엉뚱한 항목이 바뀌거나
        조용히 실패하는 사고가 나기 쉬워서(Format 메뉴만 안 바뀌던 문제가 그 예),
        아예 그 방식 자체를 없앰."""
        t = self.tr
        menubar = tk.Menu(self.root)
        self.menubar = menubar

        file_menu = tk.Menu(menubar, tearoff=0)
        file_menu.add_command(label=t("file_new"), command=self.do_new)
        file_menu.add_command(label=t("file_open"), command=self.do_open)
        file_menu.add_command(label=t("file_save"), command=self.do_save)
        file_menu.add_command(label=t("file_saveas"), command=self.do_save_as)
        menubar.add_cascade(label=t("menu_file"), menu=file_menu)

        edit_menu = tk.Menu(menubar, tearoff=0)
        edit_menu.add_command(label=t("edit_undo"), command=self.do_undo)
        edit_menu.add_command(label=t("edit_redo"), command=self.do_redo)
        edit_menu.add_separator()
        edit_menu.add_command(label=t("edit_selectall"), command=self.select_all_text)
        menubar.add_cascade(label=t("menu_edit"), menu=edit_menu)

        insert_menu = tk.Menu(menubar, tearoff=0)
        insert_menu.add_command(label=t("insert_image"), command=self.insert_image_dialog)
        insert_menu.add_command(label=t("insert_resize"), command=self.open_image_resize)
        insert_menu.add_separator()
        insert_menu.add_command(label=t("insert_paint"), command=self.open_paint)
        menubar.add_cascade(label=t("menu_insert"), menu=insert_menu)

        format_menu = tk.Menu(menubar, tearoff=0)
        format_menu.add_command(label=t("format_font"), command=self.open_font_list)
        format_menu.add_command(label=t("format_size"), command=self.open_font_size)
        format_menu.add_separator()
        format_menu.add_command(label=t("format_bold"), command=lambda: self.toggle_inline("bold"))
        format_menu.add_command(label=t("format_italic"), command=lambda: self.toggle_inline("italic"))
        format_menu.add_command(label=t("format_underline"), command=lambda: self.toggle_inline("underline"))
        format_menu.add_command(label=t("format_strike"), command=lambda: self.toggle_inline("overstrike"))
        format_menu.add_separator()
        format_menu.add_command(label=t("format_bg"), command=self.change_bg_color)
        format_menu.add_command(label=t("format_fg"), command=self.change_text_color)
        format_menu.add_separator()
        format_menu.add_command(label=t("format_border"), command=self.change_border_color)
        format_menu.add_separator()
        format_menu.add_command(label=t("format_dark"), command=self.toggle_dark_mode)
        menubar.add_cascade(label=t("menu_format"), menu=format_menu)

        self.root.config(menu=menubar)

    def _build_ui(self):
        self.root.configure(bg=GRAY)
        self.root.geometry("1000x700")
        # 창 제목은 OS 타이틀바(윗쪽 파란 커스텀 바 없이)로만 표시
        self.title_label = None

        t = self.tr
        self._build_menu()

        # ---- 툴바 ----
        toolbar = tk.Frame(self.root, bg=GRAY)
        toolbar.pack(fill="x", side="top")

        def tbtn(parent, text, cmd, **kw):
            b = tk.Button(parent, text=text, command=cmd, relief="raised", bg=GRAY, padx=6, **kw)
            b.pack(side="left", padx=2, pady=3)
            return b

        self._i18n_buttons = []  # (button, key) \ubaa9\ub85d -> apply_language()\uc5d0\uc11c text \uac31\uc2e0

        def i18n_tbtn(parent, key, cmd, **kw):
            b = tbtn(parent, t(key), cmd, **kw)
            self._i18n_buttons.append((b, key))
            return b

        i18n_tbtn(toolbar, "tb_new", self.do_new)
        i18n_tbtn(toolbar, "tb_open", self.do_open)
        i18n_tbtn(toolbar, "tb_save", self.do_save)
        tbtn(toolbar, "\u21b6", self.do_undo)
        tbtn(toolbar, "\u21b7", self.do_redo)
        self.bold_btn = tbtn(toolbar, "B", lambda: self.toggle_inline("bold"), font=("Malgun Gothic", 10, "bold"))
        self.italic_btn = tbtn(toolbar, "I", lambda: self.toggle_inline("italic"), font=("Malgun Gothic", 10, "italic"))
        self.underline_btn = tbtn(toolbar, "U", lambda: self.toggle_inline("underline"), font=("Malgun Gothic", 10, "underline"))
        self.strike_btn = tbtn(toolbar, "S", lambda: self.toggle_inline("overstrike"), font=("Malgun Gothic", 10, "overstrike"))
        i18n_tbtn(toolbar, "tb_insert", self.insert_image_dialog)
        i18n_tbtn(toolbar, "tb_paint", self.open_paint)
        i18n_tbtn(toolbar, "tb_dark", self.toggle_dark_mode)
        self.fullscreen_btn = i18n_tbtn(toolbar, "tb_fullscreen", self.toggle_fullscreen)
        self.others_btn = i18n_tbtn(toolbar, "tb_others", self.open_others_menu)
        tk.Label(toolbar, text="Made by F3L1X_", bg=GRAY, fg=DARK_GRAY,
                 font=("Malgun Gothic", 8, "italic")).pack(side="right", padx=6)

        # ---- 상태바 ----
        # tkinter pack()은 순서대로 공간을 배분하기 때문에, expand=True로 늘어나는
        # 에디터 영역보다 상태바를 먼저 배치해둬야 밑에 자리가 남아 보임
        # (반대로 하면 에디터가 남은 공간을 다 먹어버려서 상태바가 안 보이게 됨)
        self.statusbar = tk.Label(self.root, text="Chars: 0 | Words: 0 | Ln 1, Col 1", bg=GRAY,
                                   anchor="e", font=("Malgun Gothic", 9), bd=1, relief="groove")
        self.statusbar.pack(fill="x", side="bottom")

        # ---- 에디터 ----
        editor_wrap = tk.Frame(self.root, bg=GRAY, padx=6, pady=6)
        editor_wrap.pack(fill="both", expand=True)
        self.editor_border = tk.Frame(editor_wrap, bg=self.border_color, bd=3)
        self.editor_border.pack(fill="both", expand=True)

        text_frame = tk.Frame(self.editor_border, bg=GRAY, padx=2, pady=2)
        text_frame.pack(fill="both", expand=True)

        yscroll = tk.Scrollbar(text_frame)
        yscroll.pack(side="right", fill="y")
        self.editor = tk.Text(text_frame, wrap="word", undo=True, autoseparators=True,
                               font=(self.font_family, self.font_size_px), yscrollcommand=yscroll.set,
                               bg="white", fg="black", relief="flat", padx=10, pady=10)
        self.editor.pack(side="left", fill="both", expand=True)
        yscroll.config(command=self.editor.yview)

        # 서식 태그
        self.editor.tag_configure("bold", font=self._font_variant(bold=True))
        self.editor.tag_configure("italic", font=self._font_variant(italic=True))
        self.editor.tag_configure("underline", underline=True)
        self.editor.tag_configure("overstrike", overstrike=True)

        # 이벤트
        self.editor.bind("<<Modified>>", self._on_modified)
        self.editor.bind("<KeyRelease>", self._on_editor_key_release)
        self.editor.bind("<ButtonRelease-1>", self._on_editor_click_release)

    def _font_variant(self, bold=False, italic=False):
        style = []
        if bold:
            style.append("bold")
        if italic:
            style.append("italic")
        return (self.font_family, self.font_size_px, " ".join(style)) if style else (self.font_family, self.font_size_px)

    def _bind_shortcuts(self):
        r = self.root

        def guarded(fn):
            # Paint 창이 열려있는 동안엔 메모장 전역 단축키(Ctrl+Z/S/N 등)가
            # 같이 발동하면 안 됨 (원본 JS도 Paint 열려있을 때는 이 단축키들을 무시함)
            def handler(event=None):
                if self.paint_window is not None and self.paint_window.winfo_exists():
                    return
                fn()
            return handler

        r.bind_all("<Control-n>", guarded(self.do_new))
        r.bind_all("<Control-o>", guarded(self.do_open))
        r.bind_all("<Control-s>", guarded(self.do_save))
        r.bind_all("<Control-Shift-S>", guarded(self.do_save_as))
        r.bind_all("<Control-z>", guarded(self.do_undo))
        r.bind_all("<Control-y>", guarded(self.do_redo))
        r.bind_all("<Control-a>", guarded(self.select_all_text))
        r.bind_all("<Control-b>", guarded(lambda: self.toggle_inline("bold")))
        r.bind_all("<Control-u>", guarded(lambda: self.toggle_inline("underline")))
        r.bind_all("<Control-Shift-X>", guarded(lambda: self.toggle_inline("overstrike")))

        # Ctrl+I는 뺐음: X11/리눅스 계열에서는 물리적으로 Ctrl+I를 누르면 Tk에
        # "i" 키가 아니라 "Tab" 키(둘 다 아스키 0x09라서 키보드 레벨에서 같은 걸로
        # 취급됨)로 전달돼서 안정적으로 동작하지 않음. 그래서 Italic은
        # Ctrl+Shift+I로 바꿈 (이건 Tab이랑 안 겹침).
        r.bind_all("<Control-Shift-I>", guarded(lambda: self.toggle_inline("italic")))

        r.protocol("WM_DELETE_WINDOW", self._on_close)

    # ---------------- 상태 관리 ----------------
    def _on_modified(self, event=None):
        if self.editor.edit_modified():
            self.mark_unsaved()
            self.editor.edit_modified(False)

    def mark_unsaved(self):
        self.unsaved = True
        self._schedule_autosave()

    def title_update(self):
        title = (self.current_file_name or "Untitled") + self.tr("title_suffix")
        self.root.title(title)

    def update_status(self):
        content = self.editor.get("1.0", "end-1c")
        chars = len(content)
        words = len([w for w in re.split(r"\s+", content) if w])
        idx = self.editor.index("insert")
        line, col = idx.split(".")
        if self.selected_image_id and self.selected_image_id in self.images:
            info = self.images[self.selected_image_id]["pil"]
            self.statusbar.config(text=f"Image selected (Size: {info.width}x{info.height}px)")
        else:
            self.statusbar.config(text=self.tr("status_fmt").format(chars=chars, words=words, line=line, col=col))

    def toggle_fullscreen(self):
        self._is_fullscreen = not self._is_fullscreen
        self.root.attributes("-fullscreen", self._is_fullscreen)
        self.fullscreen_btn.config(text=self.tr("tb_exit_fullscreen" if self._is_fullscreen else "tb_fullscreen"))

    # ---------------- 자동 링크 ----------------
    def _on_editor_key_release(self, event):
        self.update_status()
        self._try_autolink(event)

    def _try_autolink(self, event):
        # 원본처럼: 단어를 다 타이핑하고 스페이스/엔터를 눌러야(=단어를 "지나가야") 링크로 바뀜
        if event.keysym not in ("space", "Return"):
            return
        end_index = self.editor.index("insert -1c")  # 방금 친 공백/엔터 앞, 즉 단어 끝
        line_no = end_index.split(".")[0]
        line_start = f"{line_no}.0"
        text_before = self.editor.get(line_start, end_index)
        m = re.search(r"(\S+)$", text_before)
        if not m:
            return
        word = m.group(1)
        if not URL_REGEX.fullmatch(word):
            return
        if "link" in self.editor.tag_names(f"{end_index} -1c"):
            return  # 이미 링크로 처리된 상태
        start_col = int(end_index.split(".")[1]) - len(word)
        start_index = f"{line_no}.{start_col}"
        href = word if re.match(r"^https?://", word, re.IGNORECASE) else "https://" + word
        self._make_link(start_index, end_index, href)

    def _make_link(self, start, end, href):
        self._link_counter += 1
        tagname = f"link_{self._link_counter}"
        self.editor.tag_add(tagname, start, end)
        self.editor.tag_add("link", start, end)
        self.editor.tag_configure(tagname, foreground="#0000EE", underline=True)
        self.editor.tag_bind(tagname, "<Button-1>", lambda e, h=href: webbrowser.open(h))
        self.editor.tag_bind(tagname, "<Enter>", lambda e: self.editor.config(cursor="hand2"))
        self.editor.tag_bind(tagname, "<Leave>", lambda e: self.editor.config(cursor="xterm"))

    # ---------------- 액션들 ----------------
    def toggle_inline(self, tagname):
        try:
            start = self.editor.index("sel.first")
            end = self.editor.index("sel.last")
        except tk.TclError:
            self.show_alert(self.tr("alert_select_text_first"))
            return
        ranges = self.editor.tag_ranges(tagname)
        already = False
        # 선택 구간 전체가 이미 그 태그를 갖고 있는지 대략적으로 확인
        if tagname in self.editor.tag_names("sel.first"):
            already = True
        if already:
            self.editor.tag_remove(tagname, start, end)
        else:
            self.editor.tag_add(tagname, start, end)
        self.mark_unsaved()
        self.refresh_toolbar_state()

    def refresh_toolbar_state(self):
        def is_active(tag):
            return tag in self.editor.tag_names("insert")
        self.bold_btn.config(relief="sunken" if is_active("bold") else "raised")
        self.italic_btn.config(relief="sunken" if is_active("italic") else "raised")
        self.underline_btn.config(relief="sunken" if is_active("underline") else "raised")
        self.strike_btn.config(relief="sunken" if is_active("overstrike") else "raised")
        self.update_status()

    def select_all_text(self):
        self.editor.tag_add("sel", "1.0", "end-1c")
        self.editor.focus_set()

    def do_undo(self):
        try:
            self.editor.edit_undo()
        except tk.TclError:
            pass
        self.update_status()

    def do_redo(self):
        try:
            self.editor.edit_redo()
        except tk.TclError:
            pass
        self.update_status()

    # ---------------- 파일: 새로 만들기 / 열기 / 저장 ----------------
    def reset_editor(self):
        self.editor.delete("1.0", "end")
        self.images.clear()
        self.selected_image_id = None
        self.current_file_name = None
        self.current_file_path = None
        self.unsaved = False
        self.update_status()
        self.title_update()
        self.save_autosave_now()

    def do_new(self):
        self.confirm_discard(self.reset_editor)

    def confirm_discard(self, proceed_cb):
        if not self.unsaved:
            proceed_cb()
            return
        t = self.tr
        win = tk.Toplevel(self.root)
        win.title(t("trash_title"))
        win.configure(bg=GRAY)
        win.transient(self.root)
        win.grab_set()
        tk.Label(win, text=t("trash_msg"), bg=GRAY, padx=20, pady=14, wraplength=260).pack()
        btns = tk.Frame(win, bg=GRAY)
        btns.pack(pady=(0, 14))

        def ye():
            win.destroy()
            proceed_cb()

        def nuhuh():
            win.destroy()
            self.do_save()
            proceed_cb()

        tk.Button(btns, text=t("trash_yes"), width=12, command=ye).pack(side="left", padx=6)
        tk.Button(btns, text=t("trash_no"), width=12, command=nuhuh).pack(side="left", padx=6)

    def do_open(self):
        t = self.tr
        path = filedialog.askopenfilename(
            title=t("dlg_open_title"),
            filetypes=[(t("filetype_text_html"), "*.html *.htm *.txt *.md"), (t("filetype_all"), "*.*")])
        if not path:
            return
        with open(path, "r", encoding="utf-8", errors="replace") as f:
            data = f.read()
        self.editor.delete("1.0", "end")
        self.images.clear()
        name_lower = path.lower()
        if name_lower.endswith(".md"):
            # 마크다운으로 저장해뒀던 서식(굵게/기울임/밑줄/취소선)이랑 이미지를 그대로 복원
            self._load_markdown_into_editor(data)
        elif name_lower.endswith(".txt"):
            self.editor.insert("1.0", data)
        else:
            m = re.search(r'<div id="editor"[^>]*>([\s\S]*?)</div>\s*</body>', data, re.IGNORECASE)
            html_body = m.group(1) if m else data
            self._load_html_into_editor(html_body)
        self.current_file_name = os.path.basename(path)
        self.current_file_path = path
        self.unsaved = False
        self.update_status()
        self.title_update()
        self.save_autosave_now()

    def do_save(self):
        # 이미 저장해본 경로가 있으면 그 경로에 바로 덮어씀 (매번 다시 안 물어봄)
        if self.current_file_path:
            self._write_to_path(self.current_file_path)
        else:
            self.do_save_as()

    def do_save_as(self):
        name = simpledialog.askstring(self.tr("saveas_title"), self.tr("saveas_prompt"),
                                       initialvalue=self.current_file_name or "Untitled.txt")
        if not name:
            return
        # .txt(순수 텍스트) 또는 .md(마크다운 -- 굵게/기울임/밑줄/취소선, 이미지까지 보존됌)
        # 둘 중 하나로만 저장. 사용자가 이름에 다른 확장자를 적었으면 .txt로 맞춤.
        base, ext = os.path.splitext(name)
        ext = ext.lower()
        if ext != ".md":
            ext = ".txt"
        name = base + ext
        t = self.tr
        path = filedialog.asksaveasfilename(
            title=t("dlg_saveas_title"), initialfile=name, defaultextension=ext,
            filetypes=[(t("filetype_text"), "*.txt"), (t("filetype_markdown"), "*.md"),
                       (t("filetype_all"), "*.*")])
        if not path:
            return
        self.current_file_name = os.path.basename(path)
        self.current_file_path = path
        self._write_to_path(path)
        self.title_update()

    def _write_to_path(self, path):
        is_markdown = path.lower().endswith(".md")
        if is_markdown:
            # 굵게/기울임/밑줄/취소선이랑 이미지까지 마크다운 문법으로 그대로 저장함 ->
            # 나중에 이 .md 파일을 다시 열면 _load_markdown_into_editor가 똑같이 복원함
            content = self.export_markdown()
        else:
            content = self.editor.get("1.0", "end-1c")
        with open(path, "w", encoding="utf-8") as f:
            f.write(content)
        self.unsaved = False
        self.title_update()
        if is_markdown:
            self.show_alert(self.tr("alert_saved_markdown_note"), self.tr("alert_saved_title"))
        elif any(k.startswith("img") for k in self.images):
            self.show_alert(self.tr("alert_saved_with_image_note"), self.tr("alert_saved_title"))
        else:
            self.show_alert(self.tr("alert_saved_plain"), self.tr("alert_saved_title"))

    # ---------------- HTML 내보내기 / 불러오기 ----------------
    def export_html(self):
        """에디터 내용을 (거의) 원본과 같은 형식의 인라인 HTML로 직렬화."""
        parts = []
        open_tags = {"bold": False, "italic": False, "underline": False, "overstrike": False}
        tagorder = ["bold", "italic", "underline", "overstrike"]
        tagmap = {"bold": "b", "italic": "i", "underline": "u", "overstrike": "s"}

        def close_all():
            for t in reversed(tagorder):
                if open_tags[t]:
                    parts.append(f"</{tagmap[t]}>")
                    open_tags[t] = False

        def sync_tags(active):
            # 닫아야 할 것부터 역순으로 닫고, 새로 열 것은 순서대로 연다 (중첩 유지)
            for t in reversed(tagorder):
                if open_tags[t] and t not in active:
                    parts.append(f"</{tagmap[t]}>")
                    open_tags[t] = False
            for t in tagorder:
                if t in active and not open_tags[t]:
                    parts.append(f"<{tagmap[t]}>")
                    open_tags[t] = True

        dump = self.editor.dump("1.0", "end-1c", tag=True, text=True, image=True)
        active = set()
        for key, value, index in dump:
            if key == "tagon" and value in tagorder:
                active.add(value)
            elif key == "tagoff" and value in tagorder:
                active.discard(value)
            elif key == "text":
                sync_tags(active)
                escaped = (value.replace("&", "&amp;").replace("<", "&lt;")
                           .replace(">", "&gt;").replace("\n", "<br>"))
                parts.append(escaped)
            elif key == "image":
                img_id = value
                if img_id in self.images:
                    b64 = self._pil_to_base64(self.images[img_id]["pil"])
                    w, h = self.images[img_id]["pil"].size
                    parts.append(f'<img src="data:image/png;base64,{b64}" style="width:{w}px;height:{h}px;">')
        close_all()
        return "".join(parts)

    def _pil_to_base64(self, pil_img):
        buf = io.BytesIO()
        pil_img.save(buf, format="PNG")
        return base64.b64encode(buf.getvalue()).decode("ascii")

    def _load_html_into_editor(self, html_fragment):
        parser = _SimpleHTMLImporter(self)
        parser.feed(html_fragment)

    # ---------------- 마크다운(.md) 내보내기 / 불러오기 ----------------
    # txt로만 저장하면 굵게/기울임/밑줄/취소선, 이미지가 전부 날아가는 문제 때문에
    # 추가한 포맷. export_html()이랑 똑같은 굵게/기울임/밑줄/취소선/이미지 정보를
    # 마크다운 문법(**굵게**, *기울임*, ~~취소선~~, 밑줄은 <u>, 이미지는 <img ...>)으로
    # 바꿔서 저장하고, _load_markdown_into_editor가 그걸 다시 그대로 복원함.
    _MD_ESCAPE_CHARS = "\\*_~<>"
    _EXTRA_TAG_PREFIXES = ("fg_", "hl_", "ulc_", "stc_", "size_")

    @staticmethod
    def _md_escape(text):
        # 사용자가 원래 쓴 글 안에 *, _, ~, <, > 같은 글자가 있으면 마크다운 문법이랑
        # 헷갈릴 수 있어서, 저장할 때 백슬래시를 붙여둠 (불러올 때 다시 풀어줌)
        out = []
        for ch in text:
            if ch in NotepadApp._MD_ESCAPE_CHARS:
                out.append("\\")
            out.append(ch)
        return "".join(out)

    def export_markdown(self):
        """에디터 내용을 굵게/기울임/밑줄/취소선 서식이랑 이미지를 보존한
        마크다운 텍스트로 직렬화."""
        parts = []
        open_tags = {"bold": False, "italic": False, "underline": False, "overstrike": False}
        tagorder = ["bold", "italic", "underline", "overstrike"]
        open_delim = {"bold": "**", "italic": "*", "underline": "<u>", "overstrike": "~~"}
        close_delim = {"bold": "**", "italic": "*", "underline": "</u>", "overstrike": "~~"}

        def close_all():
            for tg in reversed(tagorder):
                if open_tags[tg]:
                    parts.append(close_delim[tg])
                    open_tags[tg] = False

        def sync_tags(active):
            for tg in reversed(tagorder):
                if open_tags[tg] and tg not in active:
                    parts.append(close_delim[tg])
                    open_tags[tg] = False
            for tg in tagorder:
                if tg in active and not open_tags[tg]:
                    parts.append(open_delim[tg])
                    open_tags[tg] = True

        dump = self.editor.dump("1.0", "end-1c", tag=True, text=True, image=True)
        active = set()
        extra = set()  # 글자색/형광펜/밑줄색/취소선색/크기 태그 (fg_, hl_, ulc_, stc_, size_)
        for key, value, index in dump:
            if key == "tagon" and value in tagorder:
                active.add(value)
            elif key == "tagoff" and value in tagorder:
                active.discard(value)
            elif key == "tagon" and value.startswith(self._EXTRA_TAG_PREFIXES):
                extra.add(value)
            elif key == "tagoff" and value.startswith(self._EXTRA_TAG_PREFIXES):
                extra.discard(value)
            elif key == "text":
                sync_tags(active)
                escaped = self._md_escape(value)
                if extra:
                    # 마크다운엔 색 문법이 없어서 <span>에 태그 이름을 그대로 적어둠
                    parts.append(f'<span data-tags="{" ".join(sorted(extra))}">{escaped}</span>')
                else:
                    parts.append(escaped)
            elif key == "image":
                img_id = value
                if img_id in self.images:
                    b64 = self._pil_to_base64(self.images[img_id]["pil"])
                    w, h = self.images[img_id]["pil"].size
                    parts.append(f'<img src="data:image/png;base64,{b64}" width="{w}" height="{h}">')
        close_all()
        return "".join(parts)

    def _load_markdown_into_editor(self, text):
        """export_markdown()으로 저장한 텍스트를 다시 서식 있는 상태로 복원."""
        i = 0
        n = len(text)
        active = set()
        extra_tags = []

        def style():
            return {"bold": "bold" in active, "italic": "italic" in active,
                    "underline": "underline" in active, "strike": "overstrike" in active,
                    "extra": list(extra_tags)}

        while i < n:
            ch = text[i]
            if ch == "\\" and i + 1 < n and text[i + 1] in self._MD_ESCAPE_CHARS:
                self.insert_plain_text(text[i + 1], style())
                i += 2
                continue
            if text.startswith("<img ", i) or text.startswith("<img>", i):
                end = text.find(">", i)
                if end != -1:
                    tag_src = text[i:end + 1]
                    m = re.search(r'src="([^"]*)"', tag_src)
                    if m:
                        self.insert_image_from_src(m.group(1))
                    i = end + 1
                    continue
            if text.startswith("<span ", i):
                end = text.find(">", i)
                if end != -1:
                    m = re.search(r'data-tags="([^"]*)"', text[i:end + 1])
                    extra_tags[:] = m.group(1).split() if m else []
                    i = end + 1
                    continue
            if text.startswith("</span>", i):
                extra_tags[:] = []
                i += 7
                continue
            if text.startswith("<u>", i):
                active.add("underline")
                i += 3
                continue
            if text.startswith("</u>", i):
                active.discard("underline")
                i += 4
                continue
            if text.startswith("**", i):
                if "bold" in active:
                    active.discard("bold")
                else:
                    active.add("bold")
                i += 2
                continue
            if text.startswith("~~", i):
                if "overstrike" in active:
                    active.discard("overstrike")
                else:
                    active.add("overstrike")
                i += 2
                continue
            if ch == "*":
                if "italic" in active:
                    active.discard("italic")
                else:
                    active.add("italic")
                i += 1
                continue
            self.insert_plain_text(ch, style())
            i += 1

    def insert_plain_text(self, text, style):
        tags = []
        if style.get("bold"):
            tags.append("bold")
        if style.get("italic"):
            tags.append("italic")
        if style.get("underline"):
            tags.append("underline")
        if style.get("strike"):
            tags.append("overstrike")
        for name in style.get("extra", ()):
            self._ensure_extra_tag(name)
            tags.append(name)
        self.editor.insert("end", text, tuple(tags))

    def _ensure_extra_tag(self, name):
        """저장된 파일에서 읽어온 색/형광펜/크기 태그를 에디터에 다시 정의함."""
        val = name.split("_", 1)[1] if "_" in name else ""
        try:
            if name.startswith("fg_"):
                self.editor.tag_configure(name, foreground=val)
            elif name.startswith("hl_"):
                self.editor.tag_configure(name, background=val)
            elif name.startswith("ulc_"):
                try:
                    self.editor.tag_configure(name, underline=True, underlinefg=val)
                except tk.TclError:
                    self.editor.tag_configure(name, underline=True)
            elif name.startswith("stc_"):
                try:
                    self.editor.tag_configure(name, overstrike=True, overstrikefg=val)
                except tk.TclError:
                    self.editor.tag_configure(name, overstrike=True)
            elif name.startswith("size_"):
                self.editor.tag_configure(name, font=(self.font_family, int(val)))
        except (tk.TclError, ValueError):
            pass

    def insert_image_from_src(self, src):
        try:
            if src.startswith("data:image"):
                b64data = src.split(",", 1)[1]
                raw = base64.b64decode(b64data)
                pil_img = Image.open(io.BytesIO(raw)).convert("RGBA")
            else:
                pil_img = Image.open(src).convert("RGBA")
        except Exception:
            return
        self._insert_pil_image(pil_img, at_cursor=False)

    # ---------------- 이미지 ----------------
    def insert_image_dialog(self):
        path = filedialog.askopenfilename(
            title=self.tr("dlg_insertimage_title"),
            filetypes=[(self.tr("filetype_images"), "*.png *.jpg *.jpeg *.gif *.bmp *.webp")])
        if not path:
            return
        try:
            pil_img = Image.open(path).convert("RGBA")
        except Exception as e:
            self.show_alert(self.tr("alert_image_open_fail").format(err=e), self.tr("alert_error_title"))
            return
        self._insert_pil_image(pil_img, at_cursor=True)

    def _insert_pil_image(self, pil_img, at_cursor=True):
        # 원본처럼 최대 폭 400px 로 제한
        display_img = pil_img.copy()
        if display_img.width > 400:
            ratio = 400 / display_img.width
            display_img = display_img.resize((400, max(1, int(display_img.height * ratio))), Image.LANCZOS)
        photo = ImageTk.PhotoImage(display_img)

        self._img_counter += 1
        img_id = f"img{self._img_counter}"

        self.editor.focus_set()
        if at_cursor:
            index = self.editor.index("insert")
        else:
            index = "end"
        self.editor.image_create(index, image=photo, name=img_id)
        self.images[img_id] = {"pil": pil_img, "display": display_img, "photo": photo}

        tagname = f"imgtag_{img_id}"
        start = self.editor.index(index) if at_cursor else self.editor.index("end - 2c")
        end = f"{start} + 1c"
        self.editor.tag_add(tagname, start, end)
        self.editor.tag_bind(tagname, "<Button-1>", lambda e, iid=img_id: self.select_image(iid))

        self.mark_unsaved()
        self.update_status()

    def select_image(self, img_id):
        self.selected_image_id = img_id
        self.update_status()

    def _deselect_image(self):
        if self.selected_image_id:
            self.selected_image_id = None
            self.update_status()

    def _on_editor_click_release(self, event):
        # 이미지 위를 클릭한 경우는 select_image()가 이미 처리했으니 여기서 다시
        # 풀어버리면 안 됨 -- 진짜로 이미지가 아닌 곳을 클릭했을 때만 선택 해제
        self.update_status()
        try:
            idx = self.editor.index(f"@{event.x},{event.y}")
        except tk.TclError:
            return
        tags_here = self.editor.tag_names(idx)
        if not any(t.startswith("imgtag_") for t in tags_here):
            self._deselect_image()

    def open_image_resize(self):
        if not self.selected_image_id:
            self.show_alert(self.tr("alert_click_image_first"))
            return
        info = self.images[self.selected_image_id]
        cur_w, cur_h = info["display"].size
        t = self.tr

        win = tk.Toplevel(self.root)
        win.title(t("dlg_resize_title"))
        win.configure(bg=GRAY)
        win.transient(self.root)
        win.grab_set()
        tk.Label(win, text=t("dlg_resize_width"), bg=GRAY).grid(row=0, column=0, sticky="w", padx=10, pady=(10, 2))
        w_var = tk.IntVar(value=cur_w)
        tk.Entry(win, textvariable=w_var).grid(row=1, column=0, padx=10)
        tk.Label(win, text=t("dlg_resize_height"), bg=GRAY).grid(row=2, column=0, sticky="w", padx=10, pady=(8, 2))
        h_var = tk.IntVar(value=cur_h)
        tk.Entry(win, textvariable=h_var).grid(row=3, column=0, padx=10)
        keep_ratio = tk.BooleanVar(value=True)
        tk.Checkbutton(win, text=t("dlg_resize_keepratio"), variable=keep_ratio, bg=GRAY).grid(
            row=4, column=0, sticky="w", padx=10, pady=8)

        ratio = info["pil"].height / info["pil"].width
        syncing = {"on": False}  # w<->h가 서로를 무한히 갱신하는 걸 막는 재진입 방지 플래그

        def w_changed(*_):
            if syncing["on"] or not keep_ratio.get():
                return
            try:
                syncing["on"] = True
                h_var.set(round(w_var.get() * ratio))
            except Exception:
                pass
            finally:
                syncing["on"] = False

        def h_changed(*_):
            if syncing["on"] or not keep_ratio.get():
                return
            try:
                syncing["on"] = True
                w_var.set(round(h_var.get() / ratio))
            except Exception:
                pass
            finally:
                syncing["on"] = False

        w_var.trace_add("write", w_changed)
        h_var.trace_add("write", h_changed)

        def apply():
            w = clamp(w_var.get(), 10, 4000)
            h = clamp(h_var.get(), 10, 4000)
            new_display = info["pil"].resize((w, h), Image.LANCZOS)
            new_photo = ImageTk.PhotoImage(new_display)
            info["display"] = new_display
            info["photo"] = new_photo
            self.editor.image_configure(self.selected_image_id, image=new_photo)
            self.mark_unsaved()
            win.destroy()

        btns = tk.Frame(win, bg=GRAY)
        btns.grid(row=5, column=0, pady=(0, 10))
        tk.Button(btns, text=t("dlg_apply"), command=apply).pack(side="left", padx=6)
        tk.Button(btns, text=t("dlg_cancel"), command=win.destroy).pack(side="left", padx=6)

    # ---------------- 폰트 ----------------
    def open_font_list(self):
        t = self.tr
        win = tk.Toplevel(self.root)
        win.title(t("dlg_font_title"))
        win.configure(bg=GRAY)
        win.transient(self.root)
        win.grab_set()
        lb = tk.Listbox(win, height=10, width=30)
        lb.pack(padx=10, pady=10)
        for i, f in enumerate(AVAILABLE_FONTS):
            lb.insert("end", f)
            if f == self.font_family:
                lb.selection_set(i)

        def apply():
            sel = lb.curselection()
            if sel:
                self.font_family = AVAILABLE_FONTS[sel[0]]
                self.editor.configure(font=(self.font_family, self.font_size_px))
                self.mark_unsaved()
            win.destroy()

        btns = tk.Frame(win, bg=GRAY)
        btns.pack(pady=(0, 10))
        tk.Button(btns, text=t("dlg_apply"), command=apply).pack(side="left", padx=6)
        tk.Button(btns, text=t("dlg_cancel"), command=win.destroy).pack(side="left", padx=6)

    def open_font_size(self):
        t = self.tr
        win = tk.Toplevel(self.root)
        win.title(t("dlg_fontsize_title"))
        win.configure(bg=GRAY)
        win.transient(self.root)
        win.grab_set()
        tk.Label(win, text=t("dlg_fontsize_desc"),
                 bg=GRAY, fg=DARK_GRAY, wraplength=260, font=("Malgun Gothic", 8)).pack(padx=10, pady=(10, 4))
        tk.Label(win, text=t("dlg_fontsize_label"), bg=GRAY).pack(anchor="w", padx=10)
        size_var = tk.IntVar(value=self.font_size_px)
        tk.Entry(win, textvariable=size_var).pack(padx=10, fill="x")

        def apply():
            try:
                px = clamp(int(size_var.get()), 6, 200)
            except Exception:
                self.show_alert(self.tr("alert_numbers_only"), self.tr("alert_error_title"))
                return
            try:
                start = self.editor.index("sel.first")
                end = self.editor.index("sel.last")
                had_sel = True
            except tk.TclError:
                had_sel = False
            if had_sel:
                tagname = f"size_{px}"
                self.editor.tag_configure(tagname, font=(self.font_family, px))
                self.editor.tag_add(tagname, start, end)
            else:
                self.font_size_px = px
                self.editor.configure(font=(self.font_family, px))
            self.mark_unsaved()
            win.destroy()

        btns = tk.Frame(win, bg=GRAY)
        btns.pack(pady=10)
        tk.Button(btns, text=t("dlg_apply"), command=apply).pack(side="left", padx=6)
        tk.Button(btns, text=t("dlg_cancel"), command=win.destroy).pack(side="left", padx=6)

    # ---------------- 색상 ----------------
    def _pick_color(self, default):
        from tkinter import colorchooser
        color = colorchooser.askcolor(color=default, parent=self.root, title=self.tr("colorpicker_title"))
        return color[1] if color and color[1] else None

    def change_bg_color(self):
        color = self._pick_color("#ffffff")
        if color:
            self.editor.configure(bg=color)
            self.dark_mode = False
            self.mark_unsaved()

    def change_text_color(self):
        try:
            start = self.editor.index("sel.first")
            end = self.editor.index("sel.last")
        except tk.TclError:
            self.show_alert(self.tr("alert_select_text_color_first"))
            return
        color = self._pick_color("#000000")
        if color:
            tagname = f"fg_{color}"
            self.editor.tag_configure(tagname, foreground=color)
            self.editor.tag_add(tagname, start, end)
            self.mark_unsaved()

    # ---------------- 고급 서식 (밑줄/취소선 색상, 형광펜) ----------------
    def _get_selection(self):
        try:
            return self.editor.index("sel.first"), self.editor.index("sel.last")
        except tk.TclError:
            return None, None

    def set_underline_color(self):
        start, end = self._get_selection()
        if start is None:
            self.show_alert(self.tr("alert_select_text_color_first"))
            return
        color = self._pick_color("#000000")
        if not color:
            return
        tagname = f"ulc_{color}"
        try:
            # Tk 8.6.6 이상에서만 되는 옵션 -- 밑줄 자체는 항상 켜지지만, 색은
            # 이 옵션을 지원하는 버전에서만 적용됨 (지원 안 하면 그냥 기본 색 밑줄)
            self.editor.tag_configure(tagname, underline=True, underlinefg=color)
        except tk.TclError:
            self.editor.tag_configure(tagname, underline=True)
        self.editor.tag_add(tagname, start, end)
        self.mark_unsaved()

    def set_strike_color(self):
        start, end = self._get_selection()
        if start is None:
            self.show_alert(self.tr("alert_select_text_color_first"))
            return
        color = self._pick_color("#000000")
        if not color:
            return
        tagname = f"stc_{color}"
        try:
            self.editor.tag_configure(tagname, overstrike=True, overstrikefg=color)
        except tk.TclError:
            self.editor.tag_configure(tagname, overstrike=True)
        self.editor.tag_add(tagname, start, end)
        self.mark_unsaved()

    def set_highlight_color(self):
        start, end = self._get_selection()
        if start is None:
            self.show_alert(self.tr("alert_select_text_color_first"))
            return
        color = self._pick_color("#FFFF00")
        if not color:
            return
        tagname = f"hl_{color}"
        self.editor.tag_configure(tagname, background=color)
        self.editor.tag_add(tagname, start, end)
        self.mark_unsaved()

    def clear_highlight(self):
        start, end = self._get_selection()
        if start is None:
            self.show_alert(self.tr("alert_select_text_color_first"))
            return
        for tagname in self.editor.tag_names():
            if tagname.startswith("hl_"):
                self.editor.tag_remove(tagname, start, end)
        self.mark_unsaved()

    def clear_formatting(self):
        """선택한 글자의 서식(굵게/기울임/밑줄/취소선/글자색/형광펜/크기)을 전부 지움."""
        start, end = self._get_selection()
        if start is None:
            self.show_alert(self.tr("alert_select_text_color_first"))
            return
        skip_prefixes = ("link", "sel")
        for tagname in self.editor.tag_names():
            if tagname.startswith(skip_prefixes):
                continue
            if tagname in ("bold", "italic", "underline", "overstrike") or \
                    tagname.startswith(("fg_", "size_", "ulc_", "stc_", "hl_")):
                self.editor.tag_remove(tagname, start, end)
        self.mark_unsaved()

    def change_border_color(self):
        color = self._pick_color(self.border_color)
        if color:
            self.border_color = color
            self.editor_border.configure(bg=color)
            self.mark_unsaved()

    def toggle_dark_mode(self):
        self.dark_mode = not self.dark_mode
        if self.dark_mode:
            self.editor.configure(bg="#1E1E1E", fg="#E0E0E0", insertbackground="#E0E0E0")
        else:
            self.editor.configure(bg="white", fg="black", insertbackground="black")
        self.mark_unsaved()

    # ---------------- 그림판 ----------------
    def open_paint(self):
        if self.paint_window is not None and self.paint_window.winfo_exists():
            self.paint_window.lift()
            self.paint_window.focus_set()
            return
        self.paint_window = PaintWindow(self.root, self)

    def insert_finished_painting(self, pil_img):
        """Paint 창의 '문서에 삽입' 결과를 받는 콜백."""
        self._insert_pil_image(pil_img.convert("RGBA"), at_cursor=True)

    # ---------------- 알림 모달 ----------------
    def ask_yes_no(self, title, msg, yes_text, no_text):
        """번역 가능한 예/아니오 모달 (messagebox.askyesno 대체 -- 그건 버튼 글자를 못 바꿈).
        True/False를 돌려줄 때까지 이벤트 루프를 블로킹함 (wait_window)."""
        result = {"value": False}
        win = tk.Toplevel(self.root)
        win.title(title)
        win.configure(bg=GRAY)
        win.transient(self.root)
        win.grab_set()
        tk.Label(win, text=msg, bg=GRAY, padx=20, pady=14, wraplength=280, justify="left").pack()
        btns = tk.Frame(win, bg=GRAY)
        btns.pack(pady=(0, 14))

        def on_yes():
            result["value"] = True
            win.destroy()

        def on_no():
            result["value"] = False
            win.destroy()

        tk.Button(btns, text=yes_text, width=12, command=on_yes).pack(side="left", padx=6)
        tk.Button(btns, text=no_text, width=12, command=on_no).pack(side="left", padx=6)
        win.protocol("WM_DELETE_WINDOW", on_no)
        self.root.wait_window(win)
        return result["value"]

    def show_alert(self, msg, title=None):
        win = tk.Toplevel(self.root)
        win.title(title if title is not None else self.tr("notice_title"))
        win.configure(bg=GRAY)
        win.transient(self.root)
        win.grab_set()
        tk.Label(win, text=msg, bg=GRAY, padx=20, pady=14, wraplength=260).pack()
        tk.Button(win, text=self.tr("dlg_ok"), command=win.destroy, width=10).pack(pady=(0, 14))

    # ---------------- 자동 저장 ----------------
    def _schedule_autosave(self):
        if self._autosave_job:
            self.root.after_cancel(self._autosave_job)
        self._autosave_job = self.root.after(1200, self.save_autosave_now)

    def save_autosave_now(self):
        try:
            data = {
                "html": self.export_html(),
                "fontFamily": self.font_family,
                "fontSizePx": self.font_size_px,
                "fileName": self.current_file_name,
            }
            with open(AUTOSAVE_FILE, "w", encoding="utf-8") as f:
                json.dump(data, f)
        except Exception:
            pass

    def _try_restore_autosave(self):
        if not os.path.exists(AUTOSAVE_FILE):
            return
        try:
            with open(AUTOSAVE_FILE, "r", encoding="utf-8") as f:
                data = json.load(f)
        except Exception:
            return
        if not data.get("html"):
            return
        t = self.tr
        if self.ask_yes_no(t("autosave_title"), t("autosave_msg"), t("autosave_restore"), t("autosave_discard")):
            self.font_family = data.get("fontFamily", self.font_family)
            self.font_size_px = data.get("fontSizePx", self.font_size_px)
            self.editor.configure(font=(self.font_family, self.font_size_px))
            self._load_html_into_editor(data["html"])
            self.current_file_name = data.get("fileName")
            self.title_update()
        else:
            try:
                os.remove(AUTOSAVE_FILE)
            except Exception:
                pass

    def _on_close(self):
        self.save_autosave_now()
        if self.unsaved:
            t = self.tr
            if not self.ask_yes_no(t("quit_title"), t("quit_msg"), t("quit_yes"), t("quit_no")):
                return
        self.root.destroy()


# ----------------------------------------------------------------------------
# 그림판 (Paint)
# ----------------------------------------------------------------------------
class Layer:
    def __init__(self, name, width, height):
        self.name = name
        self.image = Image.new("RGBA", (width, height), (0, 0, 0, 0))
        self.visible = True
        self.alpha_locked = False


class PaintWindow(tk.Toplevel):
    def __init__(self, master, notepad, width=1920, height=1080):
        super().__init__(master)
        self.notepad = notepad
        self.t = notepad.tr  # 번역 단축 (그림판도 메모장이랑 같은 언어를 따라감)
        self.title(self.t("tb_paint"))
        self.configure(bg=GRAY)
        self.geometry("1000x680")

        self.canvas_w = width
        self.canvas_h = height
        self.layers = [Layer(self.t("paint_layer_default_name").format(n=1), width, height)]
        self.active_index = 0
        self.zoom = 1.0
        self.tool = "brush"
        self.brush_size = 8
        self.color = "#000000"
        self.history = []
        self.redo_stack = []
        self.selection = None       # {'image':PIL RGBA same size as canvas, 'bbox':(x0,y0,x1,y1)}
        self.lasso_points = []
        self.drag_start = None
        self.selection_drag_origin = None
        self._is_fullscreen = False
        self.photo_ref = None
        self.opacity_pct = 100
        # 색상 피커 같은 네이티브 모달이 떠 있는 동안은 Paint 자체 단축키(특히 Escape)가
        # 같이 반응해서 창이 꺼져버리는 버그가 있었음 -> 모달 여는 동안엔 단축키 무시
        self._shortcuts_suspended = False
        # 그림 그리다가 저장 안 하고 창을 닫으면 그동안 그린 게 다 날아가던 문제 ->
        # 뭔가 그릴 때마다(= push_history가 불릴 때마다) True로 바뀌고, PNG로
        # 저장하면 False로 돌아옴. 닫을 때 이게 True면 저장할지 물어봄.
        self.dirty = False
        # 펜/마우스를 빠르게 움직이면(특히 펜은 마우스보다 이벤트가 훨씬 자주 옴)
        # 움직일 때마다 캔버스 전체(레이어 합성 + 리사이즈 + PhotoImage 새로 생성)를
        # 다시 그리면 렉이 걸리고, 그러는 동안 이벤트가 밀려서 간혹 입력이 씹히거나
        # 스크롤 같은 다른 제스처랑 꼬이는 것처럼 보임. 그래서 한 프레임(after_idle)에
        # 실제 화면 갱신은 딱 한 번만 일어나게 요청을 묶어줌.
        self._render_scheduled = False
        self._pending_preview_lasso = False

        self._build_ui()
        self._bind_events()
        self.set_tool("brush")
        # 언어(특히 일본어)에 따라 툴바 글자 수가 길어지면 Zoom in 같은 오른쪽
        # 버튼이 창 폭 밖으로 밀려서 안 보일 수 있었음 -> 툴바가 다 들어가게 폭 보정
        self._fit_window_to_toolbar()
        # 1920x1080 같은 큰 캔버스가 화면보다 크면 다 보이게 축소해서 시작
        # (창이 실제로 화면에 배치된 뒤에 크기를 알 수 있으므로 살짝 지연)
        self.after(50, self._fit_zoom_to_view)
        self.render()

    def _fit_window_to_toolbar(self):
        """툴바 버튼 글자 수가 언어마다 달라서(특히 일본어/한국어 vs 영어),
        창 폭이 좁으면 Zoom in처럼 뒤쪽에 있는 버튼이 창 오른쪽 밖으로 밀려나가
        안 보이는 문제가 있었음. 툴바가 실제로 필요로 하는 폭을 계산해서,
        지금 창 폭이 그보다 좁으면 늘려줌 (화면 폭은 넘지 않게)."""
        self.update_idletasks()
        needed_w = max((row.winfo_reqwidth() for row in self.toolbar_rows), default=0) + 20
        cur_w = self.winfo_width()
        cur_h = self.winfo_height()
        if cur_h <= 1:
            cur_h = 680
        screen_w = self.winfo_screenwidth()
        new_w = min(max(cur_w, needed_w, 1000), screen_w - 40)
        if new_w > cur_w:
            self.geometry(f"{new_w}x{cur_h}")

    # ---------------- UI ----------------
    def _build_ui(self):
        t = self.t
        self.title(t("tb_paint"))
        self._i18n_buttons = []  # (button, key) -> retranslate()에서 text 갱신
        self._i18n_labels = []   # (label, key) -> 마찬가지

        def i18n_btn(parent, key, cmd, **kw):
            b = tk.Button(parent, text=t(key), command=cmd, **kw)
            self._i18n_buttons.append((b, key))
            return b

        def i18n_lbl(parent, key, **kw):
            l = tk.Label(parent, text=t(key), bg=GRAY, **kw)
            self._i18n_labels.append((l, key))
            return l

        # 일본어처럼 버튼 글자 수가 길어지는 언어에서는 툴바를 한 줄로 다 몰아넣으면
        # 화면 폭을 넘어가서 Zoom in 같은 뒤쪽 버튼이 창 밖으로 밀려나 안 보이게 됨.
        # 그래서 한 줄에 다 안 넣고 두 줄로 나눠서, 어떤 언어/화면 크기에서도
        # 버튼이 잘리거나 가려지지 않게 함.
        toolbar_wrap = tk.Frame(self, bg=GRAY)
        toolbar_wrap.pack(fill="x")
        self.toolbar = toolbar_wrap
        toolbar = tk.Frame(toolbar_wrap, bg=GRAY)
        toolbar.pack(fill="x")
        toolbar2 = tk.Frame(toolbar_wrap, bg=GRAY)
        toolbar2.pack(fill="x")
        self.toolbar_rows = [toolbar, toolbar2]

        i18n_btn(toolbar, "paint_undo", self.undo).pack(side="left", padx=2, pady=3)
        i18n_btn(toolbar, "paint_redo", self.redo).pack(side="left", padx=2, pady=3)

        self.tool_buttons = {}
        tool_keys = [("brush", "paint_tool_brush"), ("eraser", "paint_tool_eraser"),
                     ("eyedropper", "paint_tool_eyedropper"), ("lasso", "paint_tool_lasso"),
                     ("lasso-fill", "paint_tool_lassofill"), ("lasso-erase", "paint_tool_lassoerase")]
        for key, label_key in tool_keys:
            b = i18n_btn(toolbar, label_key, lambda k=key: self.set_tool(k))
            b.pack(side="left", padx=2, pady=3)
            self.tool_buttons[key] = b

        i18n_lbl(toolbar2, "paint_size").pack(side="left", padx=(6, 2), pady=3)
        self.size_var = tk.IntVar(value=self.brush_size)
        tk.Spinbox(toolbar2, from_=1, to=200, width=5, textvariable=self.size_var,
                   command=self._on_size_change).pack(side="left")
        self.size_var.trace_add("write", lambda *_: self._on_size_change())

        i18n_lbl(toolbar2, "paint_color").pack(side="left", padx=(10, 2))
        self.color_swatch = tk.Button(toolbar2, bg=self.color, width=3, command=self.pick_color)
        self.color_swatch.pack(side="left")

        i18n_lbl(toolbar2, "paint_opacity").pack(side="left", padx=(10, 2))
        self.opacity_var = tk.IntVar(value=self.opacity_pct)
        tk.Spinbox(toolbar2, from_=1, to=100, width=5, textvariable=self.opacity_var,
                   command=self._on_opacity_change).pack(side="left")
        self.opacity_var.trace_add("write", lambda *_: self._on_opacity_change())

        i18n_btn(toolbar2, "paint_clearlayer", self.clear_active_layer).pack(side="left", padx=(10, 2))
        i18n_btn(toolbar2, "paint_newcanvas_btn", self.open_new_canvas_dialog).pack(side="left", padx=(12, 2))
        i18n_btn(toolbar2, "paint_zoomout", self.zoom_out).pack(side="left", padx=(12, 2))
        i18n_btn(toolbar2, "paint_zoomreset", self.zoom_reset).pack(side="left", padx=2)
        i18n_btn(toolbar2, "paint_zoomin", self.zoom_in).pack(side="left", padx=2)
        self.fs_btn = i18n_btn(toolbar2, "tb_fullscreen", self.toggle_fullscreen)
        self.fs_btn.pack(side="right", padx=(2, 6))

        # 하단 버튼 줄을 body(캔버스+레이어패널, expand=True)보다 먼저 배치해야
        # pack() 배분 순서상 공간이 안 잘리고 남음 (메모장 상태바랑 같은 이유의 버그)
        bottom = tk.Frame(self, bg=GRAY)
        bottom.pack(fill="x", side="bottom")
        i18n_btn(bottom, "dlg_cancel", self.close).pack(side="right", padx=6, pady=6)
        i18n_btn(bottom, "paint_insert", self.insert_into_document).pack(side="right", padx=6, pady=6)
        i18n_btn(bottom, "paint_save_png", self.save_as_png).pack(side="left", padx=6, pady=6)

        body = tk.Frame(self)
        body.pack(fill="both", expand=True)

        canvas_area = tk.Frame(body, bg="#7a7a7a")
        canvas_area.pack(side="left", fill="both", expand=True)
        self.hbar = tk.Scrollbar(canvas_area, orient="horizontal")
        self.vbar = tk.Scrollbar(canvas_area, orient="vertical")
        self.canvas = tk.Canvas(canvas_area, bg="#7a7a7a",
                                 xscrollcommand=self.hbar.set, yscrollcommand=self.vbar.set)
        self.hbar.config(command=self.canvas.xview)
        self.vbar.config(command=self.canvas.yview)
        self.hbar.pack(side="bottom", fill="x")
        self.vbar.pack(side="right", fill="y")
        self.canvas.pack(side="left", fill="both", expand=True)
        self.canvas_image_id = self.canvas.create_image(0, 0, anchor="nw")

        layer_panel = tk.Frame(body, width=220, bg=GRAY)
        layer_panel.pack(side="right", fill="y")
        layer_panel.pack_propagate(False)
        i18n_lbl(layer_panel, "paint_layers_header", font=("Malgun Gothic", 10, "bold")).pack(
            anchor="w", padx=6, pady=4)
        self.layer_list_frame = tk.Frame(layer_panel, bg=GRAY)
        self.layer_list_frame.pack(fill="both", expand=True, padx=4)

        btns1 = tk.Frame(layer_panel, bg=GRAY)
        btns1.pack(fill="x", padx=4, pady=2)
        i18n_btn(btns1, "paint_add", self.add_layer, width=6).pack(side="left")
        i18n_btn(btns1, "paint_dup", self.duplicate_layer, width=6).pack(side="left")
        i18n_btn(btns1, "paint_del", self.delete_layer, width=6).pack(side="left")
        btns2 = tk.Frame(layer_panel, bg=GRAY)
        btns2.pack(fill="x", padx=4, pady=2)
        i18n_btn(btns2, "paint_merge", self.merge_down, width=6).pack(side="left")
        tk.Button(btns2, text="\u2191", command=self.move_layer_up, width=3).pack(side="left")
        tk.Button(btns2, text="\u2193", command=self.move_layer_down, width=3).pack(side="left")

        self.render_layer_list()

    def retranslate(self):
        """언어가 바뀔 때 (Paint 창이 열려있는 동안) 고정 UI 요소들을 다시 번역."""
        t = self.t
        self.title(t("tb_paint"))
        for btn, key in self._i18n_buttons:
            if btn is self.fs_btn:
                btn.config(text=t("tb_exit_fullscreen" if self._is_fullscreen else "tb_fullscreen"))
            else:
                btn.config(text=t(key))
        for lbl, key in self._i18n_labels:
            lbl.config(text=t(key))
        self.render_layer_list()
        # 번역 후 글자 수가 늘어났을 수 있으니 툴바 폭도 다시 맞춰줌
        self._fit_window_to_toolbar()

    def _bind_events(self):
        self.canvas.bind("<ButtonPress-1>", self.on_canvas_down)
        self.canvas.bind("<B1-Motion>", self.on_canvas_drag)
        self.canvas.bind("<ButtonRelease-1>", self.on_canvas_up)
        self.bind("<Key>", self.on_key)
        self.protocol("WM_DELETE_WINDOW", self.close)

    # ---------------- 도구 ----------------
    def set_tool(self, tool):
        self.tool = tool
        self.lasso_points = []
        for key, btn in self.tool_buttons.items():
            btn.config(relief="sunken" if key == tool else "raised")

    def _on_size_change(self):
        try:
            self.brush_size = max(1, int(self.size_var.get()))
        except Exception:
            pass

    def _on_opacity_change(self):
        try:
            self.opacity_pct = clamp(int(self.opacity_var.get()), 1, 100)
        except Exception:
            pass

    def pick_color(self):
        from tkinter import colorchooser
        self._shortcuts_suspended = True
        try:
            c = colorchooser.askcolor(color=self.color, parent=self, title=self.t("colorpicker_title"))
        finally:
            self._shortcuts_suspended = False
        if c and c[1]:
            self.color = c[1]
            self.color_swatch.config(bg=self.color)

    # ---------------- 좌표 변환 ----------------
    def _canvas_to_image_xy(self, event):
        cx = self.canvas.canvasx(event.x)
        cy = self.canvas.canvasy(event.y)
        return cx / self.zoom, cy / self.zoom

    # ---------------- 그리기 ----------------
    def push_history(self):
        snap = [(l.name, l.image.copy(), l.visible, l.alpha_locked) for l in self.layers]
        self.history.append((snap, self.active_index))
        if len(self.history) > 40:
            self.history.pop(0)
        self.redo_stack.clear()
        self.update_undo_redo_buttons()
        self.dirty = True

    def undo(self):
        if not self.history:
            return
        cur_snap = [(l.name, l.image.copy(), l.visible, l.alpha_locked) for l in self.layers]
        self.redo_stack.append((cur_snap, self.active_index))
        snap, idx = self.history.pop()
        self._restore_snapshot(snap, idx)
        self.update_undo_redo_buttons()

    def redo(self):
        if not self.redo_stack:
            return
        cur_snap = [(l.name, l.image.copy(), l.visible, l.alpha_locked) for l in self.layers]
        self.history.append((cur_snap, self.active_index))
        snap, idx = self.redo_stack.pop()
        self._restore_snapshot(snap, idx)
        self.update_undo_redo_buttons()

    def _restore_snapshot(self, snap, idx):
        self.layers = []
        for name, img, vis, lock in snap:
            l = Layer(name, img.width, img.height)
            l.image = img
            l.visible = vis
            l.alpha_locked = lock
            self.layers.append(l)
        self.active_index = min(idx, len(self.layers) - 1)
        self.canvas_w, self.canvas_h = self.layers[0].image.size
        self.render_layer_list()
        self.render()

    def update_undo_redo_buttons(self):
        pass  # 버튼 활성/비활성은 생략(항상 클릭 가능, 스택 비어있으면 그냥 무시)

    def on_canvas_down(self, event):
        # 펜/마우스 입력이 캔버스에 확실히 꽂히게 포커스를 먼저 가져옴 (안 그러면
        # 간혹 다른 위젯이 포커스를 들고 있어서 스크롤 같은 다른 동작으로 샐 수 있음)
        self.canvas.focus_set()
        x, y = self._canvas_to_image_xy(event)
        if self.tool in ("brush", "eraser"):
            self.push_history()
            self.drag_start = (x, y)
            self._stroke_point(x, y)
            self.render()
        elif self.tool == "eyedropper":
            self._eyedrop(x, y)
        elif self.tool in ("lasso", "lasso-fill", "lasso-erase"):
            if self.selection is not None and self.tool == "lasso":
                # 이미 떠 있는 선택 영역을 드래그로 옮기기 시작
                self.selection_drag_origin = (x, y)
            else:
                self.lasso_points = [(x, y)]

    def on_canvas_drag(self, event):
        x, y = self._canvas_to_image_xy(event)
        if self.tool in ("brush", "eraser"):
            # 획을 그리는 것 자체(레이어 이미지에 붓칠하는 것)는 매번 하되, 화면을
            # 다시 그리는 건 묶어서 처리함 (렉 완화 -- _request_render 설명 참고)
            self._stroke_point(x, y)
            self._request_render()
        elif self.tool in ("lasso", "lasso-fill", "lasso-erase"):
            if self.selection is not None and self.selection_drag_origin is not None and self.tool == "lasso":
                dx = x - self.selection_drag_origin[0]
                dy = y - self.selection_drag_origin[1]
                self.selection["x"] += dx
                self.selection["y"] += dy
                self.selection_drag_origin = (x, y)
                self._request_render()
            else:
                self.lasso_points.append((x, y))
                self._request_render(preview_lasso=True)

    def on_canvas_up(self, event):
        if self.tool in ("brush", "eraser"):
            self.drag_start = None
            self.notepad.mark_unsaved()
        elif self.tool == "lasso":
            if self.selection is not None and self.selection_drag_origin is not None:
                self._commit_selection()
                self.selection_drag_origin = None
            elif len(self.lasso_points) >= 3:
                self.push_history()
                self._cut_lasso_selection()
        elif self.tool == "lasso-fill":
            if len(self.lasso_points) >= 3:
                self.push_history()
                self._fill_lasso(self.color)
        elif self.tool == "lasso-erase":
            if len(self.lasso_points) >= 3:
                self.push_history()
                self._fill_lasso((0, 0, 0, 0))
        self.render()

    def _stroke_point(self, x, y):
        """브러시/지우개 한 구간을 그림. 불투명도(opacity)와 알파잠금(alpha lock)을
        원본(JS Canvas의 globalAlpha / source-atop / destination-out)과 비슷하게 재현."""
        layer = self.layers[self.active_index]
        r = self.brush_size / 2
        p0 = self.drag_start if self.drag_start else (x, y)
        p1 = (x, y)

        # 이번 구간이 차지하는 영역만 잘라서 작업 (전체 캔버스에 매번 합성하면 느림)
        pad = r + 2
        bx0 = clamp(int(min(p0[0], p1[0]) - pad), 0, self.canvas_w)
        by0 = clamp(int(min(p0[1], p1[1]) - pad), 0, self.canvas_h)
        bx1 = clamp(int(max(p0[0], p1[0]) + pad) + 1, 0, self.canvas_w)
        by1 = clamp(int(max(p0[1], p1[1]) + pad) + 1, 0, self.canvas_h)
        self.drag_start = (x, y)
        if bx1 <= bx0 or by1 <= by0:
            return

        ox, oy = bx0, by0
        w, h = bx1 - bx0, by1 - by0

        # 브러시 모양(원+선)을 흑백 마스크로 그리기
        shape_mask = Image.new("L", (w, h), 0)
        sd = ImageDraw.Draw(shape_mask)
        lp0 = (p0[0] - ox, p0[1] - oy)
        lp1 = (p1[0] - ox, p1[1] - oy)
        if lp0 != lp1:
            sd.line([lp0, lp1], fill=255, width=self.brush_size)
        sd.ellipse([lp1[0] - r, lp1[1] - r, lp1[0] + r, lp1[1] + r], fill=255)
        sd.ellipse([lp0[0] - r, lp0[1] - r, lp0[0] + r, lp0[1] + r], fill=255)

        opacity = self.opacity_pct / 100.0
        if opacity < 1.0:
            shape_mask = shape_mask.point(lambda v: int(v * opacity))

        region = layer.image.crop((bx0, by0, bx1, by1))

        if layer.alpha_locked:
            existing_alpha = region.split()[3]
            existing_mask = existing_alpha.point(lambda v: 255 if v > 0 else 0)
            shape_mask = ImageChops.multiply(shape_mask, existing_mask)

        if self.tool == "eraser":
            transparent = Image.new("RGBA", (w, h), (0, 0, 0, 0))
            region.paste(transparent, (0, 0), shape_mask)
        else:
            rgba = self._hex_to_rgba(self.color, 255)
            colored = Image.new("RGBA", (w, h), rgba)
            region.paste(colored, (0, 0), shape_mask)

        layer.image.paste(region, (bx0, by0))

    def _hex_to_rgba(self, hexcolor, alpha=255):
        hexcolor = hexcolor.lstrip("#")
        r = int(hexcolor[0:2], 16)
        g = int(hexcolor[2:4], 16)
        b = int(hexcolor[4:6], 16)
        return (r, g, b, alpha)

    def _eyedrop(self, x, y):
        composite = self._composite_transparent()
        xi, yi = int(x), int(y)
        if 0 <= xi < composite.width and 0 <= yi < composite.height:
            r, g, b, a = composite.getpixel((xi, yi))
            self.color = f"#{r:02x}{g:02x}{b:02x}"
            self.color_swatch.config(bg=self.color)
        # 원본처럼: 색을 찍으면 자동으로 브러시 도구로 돌아감
        self.set_tool("brush")

    def _lasso_mask(self):
        mask = Image.new("L", (self.canvas_w, self.canvas_h), 0)
        ImageDraw.Draw(mask).polygon(self.lasso_points, fill=255)
        return mask

    def _fill_lasso(self, fillcolor):
        layer = self.layers[self.active_index]
        mask = self._lasso_mask()
        if layer.alpha_locked:
            # 브러시랑 똑같이: 알파 잠금 켜져 있으면 이미 칠해진(불투명) 픽셀 위에만 적용
            existing_alpha = layer.image.split()[3]
            existing_mask = existing_alpha.point(lambda v: 255 if v > 0 else 0)
            mask = ImageChops.multiply(mask, existing_mask)
        color_img = Image.new("RGBA", layer.image.size,
                               self._hex_to_rgba(fillcolor) if isinstance(fillcolor, str) else fillcolor)
        layer.image.paste(color_img, (0, 0), mask)
        self.lasso_points = []
        self.notepad.mark_unsaved()

    def _cut_lasso_selection(self):
        layer = self.layers[self.active_index]
        mask = self._lasso_mask()
        cut_full = Image.new("RGBA", layer.image.size, (0, 0, 0, 0))
        cut_full.paste(layer.image, (0, 0), mask)
        # 원래 레이어에서는 지움 (선택한 영역만 투명하게)
        empty = Image.new("RGBA", layer.image.size, (0, 0, 0, 0))
        layer.image.paste(empty, (0, 0), mask)

        xs = [p[0] for p in self.lasso_points]
        ys = [p[1] for p in self.lasso_points]
        x0 = clamp(int(min(xs)), 0, self.canvas_w)
        y0 = clamp(int(min(ys)), 0, self.canvas_h)
        x1 = clamp(int(max(xs)) + 1, 0, self.canvas_w)
        y1 = clamp(int(max(ys)) + 1, 0, self.canvas_h)
        if x1 <= x0 or y1 <= y0:
            self.lasso_points = []
            return
        crop = cut_full.crop((x0, y0, x1, y1))
        self.selection = {"crop": crop, "x": x0, "y": y0}
        self.lasso_points = []
        self.notepad.mark_unsaved()

    def _commit_selection(self):
        if not self.selection:
            return
        self.push_history()
        layer = self.layers[self.active_index]
        crop = self.selection["crop"]
        layer.image.paste(crop, (int(round(self.selection["x"])), int(round(self.selection["y"]))), crop)
        self.selection = None
        self.notepad.mark_unsaved()

    # ---------------- 레이어 ----------------
    def render_layer_list(self):
        for w in self.layer_list_frame.winfo_children():
            w.destroy()
        for i in range(len(self.layers) - 1, -1, -1):
            layer = self.layers[i]
            row = tk.Frame(self.layer_list_frame, bg="#a8a8ff" if i == self.active_index else "white",
                            bd=1, relief="sunken")
            row.pack(fill="x", pady=1)
            vis_var = tk.BooleanVar(value=layer.visible)

            def toggle_vis(i=i, var=None):
                self.layers[i].visible = not self.layers[i].visible
                self.render_layer_list()
                self.render()

            tk.Checkbutton(row, variable=vis_var, command=lambda i=i: toggle_vis(i), bg=row["bg"],
                           selectcolor="white").pack(side="left")
            # 레이어 이름이 길어지면(복제를 여러 번 하거나 언어마다 글자 수가
            # 다를 때) 패널 밖으로 잘려나가지 않도록 줄바꿈시킴
            lbl = tk.Label(row, text=layer.name, bg=row["bg"], anchor="w",
                            justify="left", wraplength=130)
            lbl.pack(side="left", fill="x", expand=True)
            lbl.bind("<Button-1>", lambda e, i=i: self._select_layer(i))
            row.bind("<Button-1>", lambda e, i=i: self._select_layer(i))

            lock_var = tk.BooleanVar(value=layer.alpha_locked)

            def toggle_lock(i=i):
                self.layers[i].alpha_locked = not self.layers[i].alpha_locked
                self.render_layer_list()

            tk.Checkbutton(row, text="\U0001F512", variable=lock_var, command=lambda i=i: toggle_lock(i),
                           bg=row["bg"], selectcolor="white").pack(side="right")

    def _select_layer(self, i):
        self.active_index = i
        self.render_layer_list()

    def add_layer(self):
        self.push_history()
        name = self.t("paint_layer_default_name").format(n=len(self.layers) + 1)
        self.layers.append(Layer(name, self.canvas_w, self.canvas_h))
        self.active_index = len(self.layers) - 1
        self.render_layer_list()
        self.render()

    def delete_layer(self):
        if len(self.layers) <= 1:
            return
        self.push_history()
        self.layers.pop(self.active_index)
        self.active_index = max(0, self.active_index - 1)
        self.render_layer_list()
        self.render()

    def duplicate_layer(self):
        self.push_history()
        src = self.layers[self.active_index]
        dup = Layer(src.name + self.t("paint_layer_copy_suffix"), self.canvas_w, self.canvas_h)
        dup.image = src.image.copy()
        dup.visible = src.visible
        dup.alpha_locked = src.alpha_locked
        self.layers.insert(self.active_index + 1, dup)
        self.active_index += 1
        self.render_layer_list()
        self.render()

    def merge_down(self):
        if self.active_index <= 0:
            return
        self.push_history()
        below = self.layers[self.active_index - 1]
        below.image = Image.alpha_composite(below.image, self.layers[self.active_index].image)
        self.layers.pop(self.active_index)
        self.active_index -= 1
        self.render_layer_list()
        self.render()

    def move_layer_up(self):
        if self.active_index >= len(self.layers) - 1:
            return
        self.push_history()
        self.layers[self.active_index], self.layers[self.active_index + 1] = \
            self.layers[self.active_index + 1], self.layers[self.active_index]
        self.active_index += 1
        self.render_layer_list()
        self.render()

    def move_layer_down(self):
        if self.active_index <= 0:
            return
        self.push_history()
        self.layers[self.active_index], self.layers[self.active_index - 1] = \
            self.layers[self.active_index - 1], self.layers[self.active_index]
        self.active_index -= 1
        self.render_layer_list()
        self.render()

    def clear_active_layer(self):
        self.push_history()
        layer = self.layers[self.active_index]
        layer.image = Image.new("RGBA", (self.canvas_w, self.canvas_h), (0, 0, 0, 0))
        self.render()
        self.notepad.mark_unsaved()

    # ---------------- 캔버스 ----------------
    def open_new_canvas_dialog(self):
        t = self.t
        win = tk.Toplevel(self)
        win.title(t("paint_newcanvas_dialog_title"))
        win.configure(bg=GRAY)
        win.transient(self)
        win.grab_set()
        tk.Label(win, text=t("paint_width_label"), bg=GRAY).pack(anchor="w", padx=10, pady=(10, 2))
        w_var = tk.IntVar(value=self.canvas_w)
        tk.Entry(win, textvariable=w_var).pack(padx=10, fill="x")
        tk.Label(win, text=t("paint_height_label"), bg=GRAY).pack(anchor="w", padx=10, pady=(8, 2))
        h_var = tk.IntVar(value=self.canvas_h)
        tk.Entry(win, textvariable=h_var).pack(padx=10, fill="x")

        def apply():
            w = clamp(w_var.get(), 16, 4000)
            h = clamp(h_var.get(), 16, 4000)
            win.destroy()
            if self.layers:
                self.push_history()
            self.reset_canvas(w, h)

        btns = tk.Frame(win, bg=GRAY)
        btns.pack(pady=10)
        tk.Button(btns, text=t("paint_create"), command=apply).pack(side="left", padx=6)
        tk.Button(btns, text=t("dlg_cancel"), command=win.destroy).pack(side="left", padx=6)

    def reset_canvas(self, w, h):
        self.canvas_w, self.canvas_h = w, h
        self.layers = [Layer(self.t("paint_layer_default_name").format(n=1), w, h)]
        self.active_index = 0
        self.selection = None
        self.render_layer_list()
        self._fit_zoom_to_view()
        self.render()

    def _composite_transparent(self):
        """레이어들만 투명 배경 위에 합성 (문서에 삽입 / 스포이드용 -- 원본처럼 투명 유지)."""
        result = Image.new("RGBA", (self.canvas_w, self.canvas_h), (0, 0, 0, 0))
        for layer in self.layers:
            if layer.visible:
                result = Image.alpha_composite(result, layer.image)
        if self.selection is not None:
            crop = self.selection["crop"]
            result.paste(crop, (int(round(self.selection["x"])), int(round(self.selection["y"]))), crop)
        return result

    def _composite(self):
        """흰 배경 위에 합성 (화면 미리보기 전용 -- 원본 CSS의 흰 캔버스 배경과 동일한 용도)."""
        white_bg = Image.new("RGBA", (self.canvas_w, self.canvas_h), (255, 255, 255, 255))
        return Image.alpha_composite(white_bg, self._composite_transparent())

    def _request_render(self, preview_lasso=False):
        """빠르게 연속으로 들어오는 드래그 이벤트(특히 펜 입력)를 매번 전체 다시
        그리지 않고, 한 이벤트 루프 틱에 한 번으로 묶어서 처리함 -> 렉/입력 밀림 완화."""
        self._pending_preview_lasso = preview_lasso
        if not self._render_scheduled:
            self._render_scheduled = True
            self.after_idle(self._run_pending_render)

    def _run_pending_render(self):
        self._render_scheduled = False
        self.render(preview_lasso=self._pending_preview_lasso)

    def render(self, preview_lasso=False):
        composite = self._composite()
        if self.zoom != 1.0:
            disp = composite.resize((max(1, int(self.canvas_w * self.zoom)), max(1, int(self.canvas_h * self.zoom))),
                                     Image.NEAREST)
        else:
            disp = composite
        self.photo_ref = ImageTk.PhotoImage(disp)
        self.canvas.itemconfig(self.canvas_image_id, image=self.photo_ref)
        self.canvas.config(scrollregion=(0, 0, disp.width, disp.height))
        if preview_lasso and len(self.lasso_points) >= 2:
            pts = [(px * self.zoom, py * self.zoom) for px, py in self.lasso_points]
            self.canvas.delete("lasso_preview")
            flat = [c for p in pts for c in p]
            self.canvas.create_line(*flat, fill="#000080", dash=(4, 2), tags="lasso_preview")
        else:
            self.canvas.delete("lasso_preview")

    def zoom_in(self):
        self.zoom = clamp(self.zoom * 1.25, 0.1, 8)
        self.render()

    def zoom_out(self):
        self.zoom = clamp(self.zoom / 1.25, 0.1, 8)
        self.render()

    def zoom_reset(self):
        self.zoom = 1.0
        self.render()

    def _fit_zoom_to_view(self):
        self.update_idletasks()
        avail_w = max(50, self.canvas.winfo_width() - 24)
        avail_h = max(50, self.canvas.winfo_height() - 24)
        fit = min(avail_w / self.canvas_w, avail_h / self.canvas_h, 1.0)
        self.zoom = max(0.1, fit)
        self.render()

    def toggle_fullscreen(self):
        self._is_fullscreen = not self._is_fullscreen
        self.attributes("-fullscreen", self._is_fullscreen)
        self.fs_btn.config(text=self.t("tb_exit_fullscreen" if self._is_fullscreen else "tb_fullscreen"))

    def insert_into_document(self):
        # 원본과 동일하게 투명 배경을 유지한 채로 문서에 삽입 (흰 배경 안 깔림)
        if self.selection is not None:
            self._commit_selection()
        result = self._composite_transparent()
        self.notepad.insert_finished_painting(result)
        self.close()

    def save_as_png(self):
        """현재 그림을 PNG 파일로 저장. 배경을 채워서 저장할지(불투명) 아니면
        투명하게 저장할지 먼저 물어보고, 그 다음 OS 기본 '다른 이름으로 저장'
        창(파일 이름 입력 포함)으로 저장 위치/이름을 물어봄."""
        t = self.t
        if self.selection is not None:
            self._commit_selection()

        bg_mode = self._ask_save_bg_mode()
        if bg_mode is None:
            return False

        self._shortcuts_suspended = True
        try:
            path = filedialog.asksaveasfilename(
                parent=self,
                title=t("paint_save_png_title"),
                defaultextension=".png",
                filetypes=[(t("filetype_images"), "*.png"), (t("filetype_all"), "*.*")])
        finally:
            self._shortcuts_suspended = False
        if not path:
            return False
        if bg_mode == "bg":
            result = self._composite().convert("RGB")  # 흰 배경 깔고 알파 없이 납작하게
        else:
            result = self._composite_transparent()
        result.save(path, "PNG")
        self.dirty = False
        self._paint_alert(t("paint_save_png_success"))
        return True

    def _ask_save_bg_mode(self):
        """'배경 포함해서 저장' / '배경 없이 저장' 중 고르는 작은 모달.
        'bg' / 'transparent' / 취소하면 None을 돌려줌."""
        t = self.t
        result = {"mode": None}
        self._shortcuts_suspended = True
        win = tk.Toplevel(self)
        win.title(t("paint_save_bg_title"))
        win.configure(bg=GRAY)
        win.transient(self)
        win.grab_set()
        tk.Label(win, text=t("paint_save_bg_msg"), bg=GRAY, padx=20, pady=14,
                 wraplength=280, justify="left").pack()
        btns = tk.Frame(win, bg=GRAY)
        btns.pack(pady=(0, 14))

        def pick(mode):
            result["mode"] = mode
            win.destroy()

        tk.Button(btns, text=t("paint_save_with_bg"), width=16,
                  command=lambda: pick("bg")).pack(side="left", padx=6)
        tk.Button(btns, text=t("paint_save_without_bg"), width=16,
                  command=lambda: pick("transparent")).pack(side="left", padx=6)
        win.protocol("WM_DELETE_WINDOW", lambda: pick(None))
        self.wait_window(win)
        self._shortcuts_suspended = False
        return result["mode"]

    def _paint_alert(self, msg, title=None):
        """메모장의 show_alert랑 같은 모양이지만, Paint 창 위에 뜨게 함."""
        t = self.t
        win = tk.Toplevel(self)
        win.title(title if title is not None else t("notice_title"))
        win.configure(bg=GRAY)
        win.transient(self)
        win.grab_set()
        tk.Label(win, text=msg, bg=GRAY, padx=20, pady=14, wraplength=260).pack()
        tk.Button(win, text=t("dlg_ok"), command=win.destroy, width=10).pack(pady=(0, 14))

    def close(self):
        """저장 안 한 그림이 있으면 그냥 닫지 않고 먼저 물어봄 (안 그러면 그린 게
        전부 날아갔었음)."""
        if not self.dirty:
            self.destroy()
            return
        t = self.t
        win = tk.Toplevel(self)
        win.title(t("paint_unsaved_title"))
        win.configure(bg=GRAY)
        win.transient(self)
        win.grab_set()
        tk.Label(win, text=t("paint_unsaved_msg"), bg=GRAY, padx=20, pady=14,
                 wraplength=280, justify="left").pack()
        btns = tk.Frame(win, bg=GRAY)
        btns.pack(pady=(0, 14))

        def do_save_then_close():
            win.destroy()
            if self.save_as_png():
                self.destroy()

        def discard_close():
            win.destroy()
            self.destroy()

        def cancel():
            win.destroy()

        tk.Button(btns, text=t("paint_save_png"), width=14, command=do_save_then_close).pack(
            side="left", padx=6)
        tk.Button(btns, text=t("paint_unsaved_close"), width=14, command=discard_close).pack(
            side="left", padx=6)
        tk.Button(btns, text=t("paint_unsaved_cancel"), width=10, command=cancel).pack(
            side="left", padx=6)
        win.protocol("WM_DELETE_WINDOW", cancel)

    def on_key(self, event):
        if self._shortcuts_suspended:
            return
        typing_widget = str(self.focus_get().__class__.__name__) if self.focus_get() else ""
        if typing_widget in ("Entry", "Spinbox"):
            return
        key = event.keysym.lower()
        ctrl = bool(event.state & 0x4)
        if ctrl:
            if key == "z":
                self.undo()
            elif key == "y":
                self.redo()
            elif key == "d":
                self.duplicate_layer()
            elif key == "n":
                self.open_new_canvas_dialog()
            elif key == "e":
                self.merge_down()
            elif key == "0":
                self.zoom_reset()
            return
        if key == "escape":
            # 전체화면 상태면 Esc는 전체화면만 빠져나오고, Paint 자체를 닫진 않음
            if self._is_fullscreen:
                self.toggle_fullscreen()
            else:
                self.close()
        elif key in ("delete", "backspace") and self.selection:
            self.selection = None
            self.render()
        elif key == "b":
            self.set_tool("brush")
        elif key == "e":
            self.set_tool("eraser")
        elif key == "p":
            self.set_tool("eyedropper")
        elif key == "m":
            self.set_tool("lasso")
        elif key == "g":
            self.set_tool("lasso-fill")
        elif key == "d":
            self.set_tool("lasso-erase")
        elif key in ("plus", "equal"):
            self.zoom_in()
        elif key in ("minus", "underscore"):
            self.zoom_out()


# ----------------------------------------------------------------------------
def main():
    root = tk.Tk()
    NotepadApp(root)
    root.mainloop()


if __name__ == "__main__":
    main()
