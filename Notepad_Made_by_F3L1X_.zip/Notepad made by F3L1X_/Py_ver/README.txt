이거는 열려면 Python 따로 설치해서 열어야 됌
To open this, you need to install Python separately.

참고로 exe 아니고 그냥 py 파일인 이유는 exe로 만들기 어려워서임
Just a heads-up, it's a .py file instead of an .exe because making it into an .exe was too hard.

